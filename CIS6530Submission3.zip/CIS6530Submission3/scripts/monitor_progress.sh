#!/bin/bash
# Monitor opcode extraction progress in real-time (PyGhidra version)

OPCODE_DIR="opcode_output"
LOG_FILE="ghidra_opcode_extraction.log"
CSV_FILE="successful_opcodes.csv"
FAIL_FILE="failures.csv"

echo "=========================================="
echo "OPCODE EXTRACTION PROGRESS MONITOR"
echo "=========================================="
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# Check if extraction is running
if pgrep -f "[p]ython3.*opcode_extraction_pipeline.py" > /dev/null; then
    echo "✓ Extraction process is RUNNING"
else
    echo "⚠ Extraction process NOT detected"
fi

echo ""

# Count completed files
if [ -d "$OPCODE_DIR" ]; then
    COMPLETED=$(find "$OPCODE_DIR" -name "*.opcode" -type f | wc -l)
    echo "Completed opcode files: $COMPLETED"

    # Count total opcodes extracted
    TOTAL_OPCODES=$(cat "$OPCODE_DIR"/*.opcode 2>/dev/null | wc -l)
    echo "Total opcodes extracted: $TOTAL_OPCODES"

    # Show recent successes
    if [ -f "$CSV_FILE" ]; then
        RECENT=$(tail -n 5 "$CSV_FILE" | cut -d',' -f1,7 | grep -v "OpcodesFilename")
        if [ ! -z "$RECENT" ]; then
            echo ""
            echo "Recent completions:"
            echo "$RECENT" | while read line; do
                echo "  ✓ $line"
            done
        fi
    fi

    # Show recent failures
    if [ -f "$FAIL_FILE" ]; then
        FAIL_RECENT=$(tail -n 5 "$FAIL_FILE" | grep -v "Filename")
        if [ ! -z "$FAIL_RECENT" ]; then
            echo ""
            echo "Recent failures:"
            echo "$FAIL_RECENT" | while IFS=',' read -r file error time stamp; do
                echo "  ✗ $file — $error"
            done
        fi
    fi
else
    echo "Output directory not found: $OPCODE_DIR"
fi

echo ""

# Show recent log entries
if [ -f "$LOG_FILE" ]; then
    echo "Recent log entries:"
    echo "------------------------------------------"
    tail -n 10 "$LOG_FILE"
else
    echo "Log file not found: $LOG_FILE"
fi

echo ""
echo "=========================================="
echo "To see live updates, run:"
echo "  watch -n 5 ./monitor_progress.sh"
echo "Or tail the log:"
echo "  tail -f $LOG_FILE"
echo "=========================================="
