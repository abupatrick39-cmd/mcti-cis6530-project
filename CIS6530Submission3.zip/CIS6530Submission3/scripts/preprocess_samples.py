#!/usr/bin/env python3
"""
Preprocess malware samples before Ghidra analysis.
- Validates file formats
- Removes duplicates
- Checks file sizes
- Copies valid samples to output folder
"""

import os
import sys
import hashlib
import shutil
from pathlib import Path
from collections import defaultdict
import argparse

class SamplePreprocessor:
    def __init__(self):
        self.valid_extensions = {
            '.exe', '.dll', '.sys', '.com', '.scr',
            '.elf', '', '.bin', '.o', '.so',
            '.apk', '.dex', '.mach', '.dylib'
        }
        self.magic_numbers = {
            b'MZ': 'PE/DOS',
            b'\x7fELF': 'ELF',
            b'\xfe\xed\xfa': 'Mach-O',
            b'\xca\xfe\xba\xbe': 'Java Class',
            b'PK\x03\x04': 'ZIP/APK',
            b'dex\n': 'DEX'
        }
        self.stats = {
            'total': 0,
            'valid': 0,
            'duplicates': 0,
            'too_small': 0,
            'too_large': 0,
            'invalid_format': 0
        }
        self.seen_hashes = set()

    def get_file_hash(self, filepath):
        sha256 = hashlib.sha256()
        with open(filepath, 'rb') as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                sha256.update(chunk)
        return sha256.hexdigest()

    def check_magic_number(self, filepath):
        try:
            with open(filepath, 'rb') as f:
                header = f.read(64)
            for magic, ftype in self.magic_numbers.items():
                if header.startswith(magic):
                    return True, ftype
            if header[0:4] == b'\x7fELF':
                return True, 'ELF'
            return False, 'Unknown'
        except:
            return False, 'Error'

    def validate_file(self, filepath, min_size=1024, max_size=100*1024*1024):
        size = filepath.stat().st_size
        if size < min_size:
            return False, 'too_small'
        if size > max_size:
            return False, 'too_large'
        is_valid, ftype = self.check_magic_number(filepath)
        if not is_valid:
            return False, 'invalid_format'
        file_hash = self.get_file_hash(filepath)
        if file_hash in self.seen_hashes:
            return False, 'duplicates'
        self.seen_hashes.add(file_hash)
        return True, ftype

    def preprocess(self, input_folder, output_folder, min_size=1024, max_size=100*1024*1024):
        input_path = Path(input_folder)
        output_path = Path(output_folder)
        output_path.mkdir(parents=True, exist_ok=True)

        all_files = [item for item in input_path.rglob('*') if item.is_file()]
        print(f"Found {len(all_files)} files in {input_folder}")
        print(f"Validating files (min: {min_size/1024:.0f}KB, max: {max_size/(1024*1024):.0f}MB)...")
        print("-" * 80)

        for filepath in all_files:
            self.stats['total'] += 1
            is_valid, reason = self.validate_file(filepath, min_size, max_size)
            if is_valid:
                dest = output_path / filepath.name
                counter = 1
                while dest.exists():
                    dest = output_path / f"{filepath.stem}_{counter}{filepath.suffix}"
                    counter += 1
                shutil.copy2(filepath, dest)
                self.stats['valid'] += 1
                print(f"✓ {filepath.name:50s} [{reason}]")
            else:
                self.stats[reason] += 1
                print(f"✗ {filepath.name:50s} [SKIP: {reason}]")

        print("\n" + "=" * 80)
        print("PREPROCESSING SUMMARY")
        print("=" * 80)
        print(f"Total files scanned:     {self.stats['total']:>6}")
        print(f"Valid files copied:      {self.stats['valid']:>6}")
        print(f"Duplicates removed:      {self.stats['duplicates']:>6}")
        print(f"Too small (< {min_size/1024:.0f}KB):   {self.stats['too_small']:>6}")
        print(f"Too large (> {max_size/(1024*1024):.0f}MB): {self.stats['too_large']:>6}")
        print(f"Invalid format:          {self.stats['invalid_format']:>6}")
        print("=" * 80)
        print(f"\n✓ {self.stats['valid']} valid samples ready in {output_folder}")

def main():
    parser = argparse.ArgumentParser(
        description="Preprocess malware samples for Ghidra analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 preprocess_samples.py raw_samples preprocessed_samples
  python3 preprocess_samples.py raw_samples preprocessed_samples --min-size 512 --max-size 50000000
        """
    )
    parser.add_argument("input_folder", help="Folder containing raw malware samples")
    parser.add_argument("output_folder", help="Folder for validated samples")
    parser.add_argument("--min-size", type=int, default=1024,
                        help="Minimum file size in bytes (default: 1024)")
    parser.add_argument("--max-size", type=int, default=100*1024*1024,
                        help="Maximum file size in bytes (default: 100MB)")
    args = parser.parse_args()

    preprocessor = SamplePreprocessor()
    preprocessor.preprocess(args.input_folder, args.output_folder,
                            args.min_size, args.max_size)

if __name__ == "__main__":
    main()
