#!/usr/bin/env python3
import os
import sys
import time
import json
import csv
import argparse
import shutil
import hashlib
import subprocess
import multiprocessing
from pathlib import Path
from datetime import datetime
from multiprocessing import Process, Queue
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

# Ensure JVM compatibility across subprocesses
multiprocessing.set_start_method("spawn", force=True)
os.environ["JAVA_HOME"] = "/usr/lib/jvm/java-21-openjdk-amd64"

REQUIRED_JAVA_VERSION = "21"

def check_java_version():
    try:
        output = subprocess.check_output(["java", "-version"], stderr=subprocess.STDOUT).decode()
        version_line = output.strip().splitlines()[0]
        print(f"[INFO] Detected Java version: {version_line}")
        if f'"{REQUIRED_JAVA_VERSION}' not in output:
            print(f"[WARNING] Java {REQUIRED_JAVA_VERSION} is recommended. Proceeding with detected version.")
    except Exception as e:
        print(f"❌ Java not found or failed to run: {e}")
        sys.exit(1)

class OpcodeExtractor:
    def __init__(self, state_file="extract_state.json", 
                 log_file="ghidra_opcode_extraction.log", 
                 csv_file="successful_opcodes.csv",
                 fail_file="failures.csv"):
        self.state_file = Path(state_file)
        self.log_file = Path(log_file)
        self.csv_file = Path(csv_file)
        self.fail_file = Path(fail_file)
        self._init_logs()
        self._init_state()
        self._init_csv()
        self._init_failures()

    def _init_logs(self):
        with open(self.log_file, "w") as f:
            f.write("=" * 80 + "\n")
            f.write("GHIDRA OPCODE EXTRACTION LOG - PYGHIDRA VERSION\n")
            f.write("=" * 80 + "\n")
            f.write(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("Java Required: Version 21\n")
            f.write("=" * 80 + "\n\n")

    def _init_state(self):
        if self.state_file.exists():
            try:
                with open(self.state_file, "r") as f:
                    self.state = json.load(f)
                completed = len(self.state.get('completed', []))
                self._log("RECOVERY", f"Loaded previous state. Completed: {completed}")
            except Exception as e:
                self._log("WARNING", f"Could not load state file: {e}")
                self.state = {"completed": [], "started": [], "last": None}
        else:
            self.state = {"completed": [], "started": [], "last": None}
        self._save_state()

    def _init_csv(self):
        if not self.csv_file.exists():
            with open(self.csv_file, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "OpcodesFilename", "OriginalFilename", "MD5", "SHA256",
                    "FileSize", "OpcodeCount", "ProcessingTime", "Timestamp"
                ])

    def _init_failures(self):
        if not self.fail_file.exists():
            with open(self.fail_file, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["Filename", "Error", "ElapsedTime", "Timestamp"])

    def _save_state(self):
        with open(self.state_file, "w") as f:
            json.dump(self.state, f, indent=2)

    def _log(self, level, message):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] [{level:10s}] {message}"
        print(line)
        with open(self.log_file, "a") as f:
            f.write(line + "\n")

    def file_hashes(self, path: Path):
        md5 = hashlib.md5()
        sha256 = hashlib.sha256()
        size = 0
        with open(path, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk: break
                size += len(chunk)
                md5.update(chunk)
                sha256.update(chunk)
        return {"md5": md5.hexdigest(), "sha256": sha256.hexdigest(), "size": size}

    def extract_single(self, bin_path: Path, out_dir: Path, idx: int, timeout_s: int):
        def worker(q, binary_path, output_path):
            try:
                import pyghidra
                from ghidra.app.util.importer import AutoImporter
                from ghidra.app.util.opinion import LoadResults
                from ghidra.program.model.listing import Instruction
                from ghidra.program.model.mem import MemoryBlock
                from ghidra.base.project import GhidraProject
                from java.io import File, BufferedWriter, FileWriter
                from ghidra.util.task import ConsoleTaskMonitor
                
                # Start PyGhidra
                pyghidra.start()
                
                # Get current interpreter and create project
                interpreter = pyghidra.get_current_interpreter()
                
                # Create a temporary project
                project_location = File("/tmp/ghidra_projects")
                project_name = f"OpcodeProject_{os.getpid()}"
                
                # Create project
                project = interpreter.create_project(project_location, project_name, True)
                
                # Import the binary file using AutoImporter
                file_to_import = File(str(binary_path))
                try:
                    # Import program
                    imported_programs = AutoImporter.importByUsingBestGuess(
                        file_to_import, 
                        None,  # destination folder
                        project, 
                        None,  # consumer
                        ConsoleTaskMonitor(), 
                        False  # overwrite
                    )
                    
                    if not imported_programs or imported_programs.isEmpty():
                        q.put((False, 0, "Failed to import program"))
                        return
                    
                    # Get the first program from the import result
                    program = imported_programs.iterator().next()
                    
                    # Analyze the program
                    interpreter.analyzeAll(program)
                    
                    # Get listing and extract instructions
                    listing = program.getListing()
                    instructions = listing.getInstructions(True)  # True = forward
                    
                    # Extract opcodes (mnemonics)
                    opcode_count = 0
                    opcodes_list = []
                    
                    while instructions.hasNext():
                        instruction = instructions.next()
                        if instruction:
                            mnemonic = instruction.getMnemonicString()
                            if mnemonic and mnemonic.strip():
                                opcodes_list.append(mnemonic)
                                opcode_count += 1
                    
                    # Write opcodes to file
                    if opcode_count > 0:
                        with open(str(output_path), 'w') as f:
                            for opcode in opcodes_list:
                                f.write(opcode + '\n')
                    
                    # Close program and project
                    program.release(interpreter.get_consumer())
                    project.close()
                    
                    if opcode_count == 0:
                        q.put((False, 0, "No instructions found"))
                        return
                        
                    q.put((True, opcode_count, None))

                except Exception as import_error:
                    q.put((False, 0, f"Import/Analysis failed: {str(import_error)}"))
                    return

            except Exception as e:
                import traceback
                error_msg = f"{str(e)}\n{traceback.format_exc()}"
                q.put((False, 0, error_msg))

        original = bin_path.name
        self.state["started"].append(original)
        self.state["last"] = original
        self._save_state()

        hashes = self.file_hashes(bin_path)
        opcodes_path = out_dir / f"{original}.opcode"
        q = Queue()
        p = Process(target=worker, args=(q, bin_path, opcodes_path))
        start = time.time()
        p.start()
        p.join(timeout_s)

        if p.is_alive():
            p.terminate()
            p.join(5)
            elapsed = time.time() - start
            error = f"Timeout({timeout_s}s)"
            self._log("TIMEOUT", f"{original} exceeded {timeout_s}s and was terminated")
            with open(self.fail_file, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([original, error, f"{elapsed:.1f}s", datetime.now().isoformat()])
            return False, hashes, error, elapsed, 0

        if not q.empty():
            success, opcode_count, error = q.get()
        else:
            success, opcode_count, error = False, 0, "Process terminated without result"

        elapsed = time.time() - start

        if success:
            with open(self.csv_file, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    opcodes_path.name, original,
                    hashes["md5"], hashes["sha256"],
                    hashes["size"], opcode_count,
                    f"{elapsed:.1f}s",
                    datetime.now().isoformat()
                ])
            self.state["completed"].append(original)
            self._save_state()
            self._log("SUCCESS", f"{original} -> {opcodes_path.name} ({opcode_count} opcodes, {elapsed:.1f}s)")
            return True, hashes, None, elapsed, opcode_count
        else:
            self._log("FAILURE", f"{original}: {error[:500]}")  # Show more error details
            with open(self.fail_file, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([original, error, f"{elapsed:.1f}s", datetime.now().isoformat()])
            return False, hashes, error, elapsed, 0

    def generate_report(self, results, output_dir: Path):
        report_path = output_dir / "batch_processing_report.json"
        summary_path = output_dir / "processing_summary.txt"
        with open(report_path, "w") as f:
            json.dump(results, f, indent=2)
        total = len(results)
        success = sum(1 for r in results if r["success"])
        failed = total - success
        with open(summary_path, "w") as f:
            f.write(f"Total samples: {total}\n")
            f.write(f"Successful extractions: {success}\n")
            f.write(f"Failures: {failed}\n")
            f.write(f"Timestamp: {datetime.now().isoformat()}\n")

def main():
    check_java_version()

    parser = argparse.ArgumentParser(description="Batch opcode extraction using PyGhidra")
    parser.add_argument("input_folder", help="Path to preprocessed samples")
    parser.add_argument("output_folder", help="Path to store .opcode files")
    parser.add_argument("--workers", type=int, default=2, help="Number of parallel workers")
    parser.add_argument("--timeout", type=int, default=600, help="Timeout per sample (seconds)")
    parser.add_argument("--no-resume", action="store_true", help="Ignore previous state and start fresh")
    args = parser.parse_args()

    input_dir = Path(args.input_folder)
    output_dir = Path(args.output_folder)
    output_dir.mkdir(parents=True, exist_ok=True)

    extractor = OpcodeExtractor()

    if args.no_resume:
        extractor.state = {"completed": [], "started": [], "last": None}
        extractor._save_state()

    binaries = sorted([f for f in input_dir.glob("*") if f.is_file()])
    binaries = [f for f in binaries if f.name not in extractor.state["completed"]]

    if not binaries:
        print("No binaries to process.")
        return

    print(f"Processing {len(binaries)} binaries with {args.workers} workers...")
    
    results = []
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = {
            executor.submit(extractor.extract_single, f, output_dir, i, args.timeout): f
            for i, f in enumerate(binaries)
        }
        for future in tqdm(as_completed(futures), total=len(futures), desc="Extracting opcodes"):
            try:
                success, hashes, error, elapsed, count = future.result()
                results.append({
                    "file": futures[future].name,
                    "success": success,
                    "error": error,
                    "time": elapsed,
                    "opcodes": count
                })
            except Exception as e:
                results.append({
                    "file": futures[future].name,
                    "success": False,
                    "error": str(e),
                    "time": 0,
                    "opcodes": 0
                })

    extractor.generate_report(results, output_dir)

if __name__ == "__main__":
    main()