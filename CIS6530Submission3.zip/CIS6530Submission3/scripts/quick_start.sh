#!/bin/bash
# MALWARE OPCODE EXTRACTION PIPELINE (PyGhidra)

echo "=================================================="
echo "MALWARE OPCODE EXTRACTION PIPELINE (PyGhidra)"
echo "=================================================="
echo ""

echo "[STEP] Checking prerequisites..."

RAW_DIR="raw_samples"
PRE_DIR="preprocessed_samples"
OUT_DIR="opcode_output"

mkdir -p "$RAW_DIR" "$PRE_DIR" "$OUT_DIR"

RAW_COUNT=$(find "$RAW_DIR" -type f | wc -l)
echo "[SUCCESS] Found $RAW_COUNT files in $RAW_DIR"

JAVA_VERSION=$(java -version 2>&1 | head -n 1)
echo "[INFO] Java version: $JAVA_VERSION"

echo ""
echo "[STEP] Step 1/2: Preprocessing malware samples..."
echo "Found $RAW_COUNT files in $RAW_DIR"
echo "Validating files (min: 1KB, max: 100MB)..."

find "$RAW_DIR" -type f -size +1k -size -100M -exec cp {} "$PRE_DIR" \;
PRE_COUNT=$(find "$PRE_DIR" -type f | wc -l)
echo "✓ $PRE_COUNT valid samples ready in $PRE_DIR"
echo "[SUCCESS] Preprocessing complete. Valid samples: $PRE_COUNT"
echo ""

echo "[STEP] Step 2/2: Extracting opcodes with PyGhidra..."
echo "This may take a while. Using 2 parallel workers."
echo "You can monitor progress in: ghidra_opcode_extraction.log"
echo ""

python3 opcode_extraction_pipeline.py "$PRE_DIR" "$OUT_DIR" --workers 2 --timeout 600

echo ""
echo "[DONE] Extraction complete. Check:"
echo "  Preprocessed samples:  $PRE_DIR"
echo "  Opcode files:          $OUT_DIR"
echo "  Success log:           successful_opcodes.csv"
echo "  Failure log:           failures.csv"
echo "  Processing report:     $OUT_DIR/batch_processing_report.json"
echo "  Summary report:        $OUT_DIR/processing_summary.txt"
echo "  Full log:              ghidra_opcode_extraction.log"
