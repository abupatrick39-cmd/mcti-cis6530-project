# 1. Install dependencies
pip install pyghidra jpype1 tqdm

# 2. Set environment variables
export JAVA_HOME=/opt/jdk-21
export PATH=$JAVA_HOME/bin:$PATH

# 3. Prepare folders
mkdir -p raw_samples preprocessed_samples opcode_output

