#!/usr/bin/env python3
"""
2-gram Malware Classification with Ultra Memory-Efficient Sparse Processing
Usage: python 2gramdata_classification.py 2gramdata.h5 [--max-features 500] [--test-size 0.3]
"""

import numpy as np
import pandas as pd
import h5py
import time
import logging
import argparse
from datetime import datetime
from pathlib import Path

# Scikit-learn imports with sparse matrix support
from sklearn.model_selection import train_test_split, StratifiedShuffleSplit
from sklearn.preprocessing import LabelEncoder
from sklearn.decomposition import TruncatedSVD
from sklearn.utils.class_weight import compute_class_weight

# Memory-efficient classifiers
from sklearn.svm import LinearSVC  # More memory efficient than SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import SGDClassifier  # Memory-efficient alternative

# Metrics and evaluation
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                           f1_score, confusion_matrix, classification_report)

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Configure logging
def setup_logging():
    """Setup comprehensive logging"""
    log_filename = f"2gram_classification_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename),
            logging.StreamHandler()
        ]
    )
    return log_filename

class UltraSparseDataProcessor:
    """Ultra memory-efficient processor for 2-gram sparse malware data"""
    
    def __init__(self, max_features=500, test_size=0.3, random_state=42):
        self.max_features = max_features
        self.test_size = test_size
        self.random_state = random_state
        self.label_encoder = LabelEncoder()
        self.dim_reducer = None
        
    def load_sparse_data(self, h5_file_path):
        """Load 2-gram sparse data with minimal memory footprint"""
        logging.info(f"Loading 2-gram data from {h5_file_path}")
        
        with h5py.File(h5_file_path, 'r') as f:
            # Log dataset structure
            logging.info("Available datasets in 2-gram file:")
            for key in f.keys():
                logging.info(f"  - {key}: {f[key].shape}")
            
            # Load sparse matrix components
            if all(key in f.keys() for key in ['row', 'col', 'data', 'shape']):
                from scipy.sparse import coo_matrix, csr_matrix
                
                # Load in chunks if very large
                row = f['row'][:]
                col = f['col'][:]
                data = f['data'][:]
                shape = f['shape'][:]
                
                logging.info(f"2-gram sparse matrix shape: {shape}")
                logging.info(f"Non-zero elements: {len(data):,}")
                
                # Create sparse matrix - keep in COO initially for memory efficiency
                sparse_features = coo_matrix((data, (row, col)), shape=shape)
                X_sparse = sparse_features.tocsr()  # Convert to CSR for efficient operations
                
                # Free memory by deleting intermediate arrays
                del row, col, data, sparse_features
                
            else:
                raise ValueError("Sparse matrix components not found in HDF5 file")
            
            # Load labels
            if 'mitre_ids' in f.keys():
                y = f['mitre_ids'][:]
                if isinstance(y[0], bytes):
                    y = [label.decode('utf-8') for label in y]
                logging.info(f"Loaded {len(y)} labels")
            else:
                raise ValueError("MITRE IDs not found in HDF5 file")
        
        return X_sparse, np.array(y)
    
    def aggressive_dimensionality_reduction(self, X_sparse):
        """Aggressive dimensionality reduction for 2-gram features"""
        original_features = X_sparse.shape[1]
        target_features = min(self.max_features, original_features)
        
        logging.info(f"Aggressive dimensionality reduction: {original_features:,} -> {target_features:,} features")
        
        # Use TruncatedSVD with aggressive component selection
        svd = TruncatedSVD(n_components=target_features, 
                          random_state=self.random_state,
                          algorithm='arpack')  # More memory efficient
        
        X_reduced = svd.fit_transform(X_sparse)
        
        explained_variance = np.sum(svd.explained_variance_ratio_)
        logging.info(f"SVD explained variance: {explained_variance:.4f} ({explained_variance*100:.2f}%)")
        
        # Log top components information
        logging.info(f"Top component variance: {svd.explained_variance_ratio_[0]:.6f}")
        logging.info(f"Bottom component variance: {svd.explained_variance_ratio_[-1]:.6f}")
        
        return X_reduced, svd
    
    def memory_efficient_split(self, X_sparse, y):
        """Memory-efficient stratified train-test split"""
        logging.info("Performing memory-efficient stratified split...")
        
        unique_classes, class_counts = np.unique(y, return_counts=True)
        logging.info(f"Class distribution: {dict(zip(unique_classes, class_counts))}")
        
        # Use indices for split to avoid copying data initially
        sss = StratifiedShuffleSplit(n_splits=1, test_size=self.test_size, 
                                   random_state=self.random_state)
        
        for train_idx, test_idx in sss.split(X_sparse, y):
            # Split labels first (small memory footprint)
            y_train, y_test = y[train_idx], y[test_idx]
            
            # Split features using efficient sparse slicing
            X_train = X_sparse[train_idx]
            X_test = X_sparse[test_idx]
        
        # Verify split quality
        train_classes = np.unique(y_train)
        test_classes = np.unique(y_test)
        
        logging.info(f"Training set: {X_train.shape[0]:,} samples, {len(train_classes)} classes")
        logging.info(f"Testing set: {X_test.shape[0]:,} samples, {len(test_classes)} classes")
        logging.info(f"Training set sparsity: {1 - (X_train.nnz / (X_train.shape[0] * X_train.shape[1])):.6f}")
        logging.info(f"Testing set sparsity: {1 - (X_test.nnz / (X_test.shape[0] * X_test.shape[1])):.6f}")
        
        return X_train, X_test, y_train, y_test
    
    def preprocess_data(self, X_sparse, y):
        """Memory-efficient preprocessing pipeline for 2-gram data"""
        # Encode labels first (minimal memory)
        y_encoded = self.label_encoder.fit_transform(y)
        logging.info(f"Encoded {len(self.label_encoder.classes_)} classes")
        
        # Split data before dimensionality reduction to save memory
        X_train, X_test, y_train, y_test = self.memory_efficient_split(X_sparse, y_encoded)
        
        # Reduce dimensionality on training data only
        logging.info("Applying dimensionality reduction to training data...")
        X_train_reduced, self.dim_reducer = self.aggressive_dimensionality_reduction(X_train)
        
        # Transform test data using the same reducer
        logging.info("Transforming test data...")
        X_test_reduced = self.dim_reducer.transform(X_test)
        
        # No scaling for memory efficiency - SVD already provides some normalization
        logging.info(f"Final feature dimensions: {X_train_reduced.shape[1]}")
        logging.info(f"Training data shape: {X_train_reduced.shape}")
        logging.info(f"Testing data shape: {X_test_reduced.shape}")
        
        return X_train_reduced, X_test_reduced, y_train, y_test

class MemoryEfficientClassifier:
    """Memory-efficient classifier training and evaluation"""
    
    def __init__(self, label_encoder):
        self.label_encoder = label_encoder
        self.results = {}
        
    def train_memory_efficient_models(self, X_train, y_train, X_test, y_test):
        """Train memory-efficient classifiers"""
        
        # Calculate class weights for imbalance handling
        class_weights = compute_class_weight('balanced', classes=np.unique(y_train), y=y_train)
        class_weight_dict = dict(zip(np.unique(y_train), class_weights))
        
        # Define memory-efficient classifiers
        classifiers = {
            'Linear SVM': LinearSVC(
                class_weight='balanced',
                random_state=42,
                max_iter=2000,  # Increased for convergence
                dual=False  # Better for n_samples > n_features
            ),
            'KNN (k=3)': KNeighborsClassifier(
                n_neighbors=3,
                algorithm='auto'
            ),
            'KNN (k=5)': KNeighborsClassifier(
                n_neighbors=5,
                algorithm='auto'
            ),
            'Decision Tree': DecisionTreeClassifier(
                class_weight='balanced',
                random_state=42,
                max_depth=15,  # Increased for 2-gram complexity
                min_samples_split=5,  # Prevent overfitting
                min_samples_leaf=3
            ),
            'SGD Classifier': SGDClassifier(
                class_weight='balanced',
                random_state=42,
                max_iter=1000,
                early_stopping=True,
                n_iter_no_change=10
            )
        }
        
        # Train and evaluate each classifier
        for name, classifier in classifiers.items():
            logging.info(f"\n{'='*60}")
            logging.info(f"Training {name}")
            logging.info(f"{'='*60}")
            
            try:
                start_time = time.time()
                classifier.fit(X_train, y_train)
                training_time = time.time() - start_time
                
                # Memory-efficient prediction
                start_pred_time = time.time()
                y_pred = classifier.predict(X_test)
                prediction_time = time.time() - start_pred_time
                
                # Evaluate model
                self._evaluate_and_store(name, y_test, y_pred, training_time, prediction_time)
                
            except Exception as e:
                logging.error(f"Error training {name}: {e}")
                continue
        
        return self.results
    
    def _evaluate_and_store(self, model_name, y_true, y_pred, training_time, prediction_time):
        """Evaluate model and store results"""
        # Calculate metrics
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
        recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
        f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0)
        
        # Store results
        self.results[model_name] = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'training_time': training_time,
            'prediction_time': prediction_time,
            'y_true': y_true,
            'y_pred': y_pred
        }
        
        logging.info(f"{model_name} Results:")
        logging.info(f"  Accuracy:    {accuracy:.4f}")
        logging.info(f"  Precision:   {precision:.4f}")
        logging.info(f"  Recall:      {recall:.4f}")
        logging.info(f"  F1-Score:    {f1:.4f}")
        logging.info(f"  Training:    {training_time:.2f}s")
        logging.info(f"  Prediction:  {prediction_time:.2f}s")
        
        # Generate classification report
        class_names = self.label_encoder.classes_
        report = classification_report(y_true, y_pred, 
                                     target_names=class_names, 
                                     zero_division=0)
        logging.info(f"\nClassification Report for {model_name}:\n{report}")

class AdvancedVisualization:
    """Advanced visualization for 2-gram classification results"""
    
    def __init__(self, label_encoder):
        self.label_encoder = label_encoder
    
    def plot_compact_confusion_matrix(self, y_true, y_pred, model_name, max_classes=15):
        """Plot compact confusion matrix for many classes"""
        cm = confusion_matrix(y_true, y_pred)
        class_names = self.label_encoder.classes_
        
        # If too many classes, show only top N
        if len(class_names) > max_classes:
            # Calculate class frequencies and take top N
            class_counts = np.bincount(y_true)
            top_indices = np.argsort(class_counts)[-max_classes:]
            cm = cm[top_indices][:, top_indices]
            class_names = class_names[top_indices]
            title_suffix = f" (Top {max_classes} Classes)"
        else:
            title_suffix = ""
        
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=class_names, yticklabels=class_names,
                   annot_kws={'size': 8})
        plt.title(f'2-gram Confusion Matrix - {model_name}{title_suffix}', 
                 fontsize=14, fontweight='bold')
        plt.xlabel('Predicted Label', fontsize=11)
        plt.ylabel('True Label', fontsize=11)
        plt.xticks(rotation=45, ha='right', fontsize=8)
        plt.yticks(rotation=0, fontsize=8)
        plt.tight_layout()
        plt.savefig(f'2gram_confusion_matrix_{model_name.lower().replace(" ", "_")}.pdf', 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_performance_radar(self, results):
        """Create radar chart for model performance comparison"""
        models = list(results.keys())
        metrics = ['accuracy', 'precision', 'recall', 'f1_score']
        
        # Prepare data for radar chart
        angles = np.linspace(0, 2*np.pi, len(metrics), endpoint=False).tolist()
        angles += angles[:1]  # Complete the circle
        
        fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
        
        colors = plt.cm.Set2(np.linspace(0, 1, len(models)))
        
        for idx, (model, color) in enumerate(zip(models, colors)):
            values = [results[model][metric] for metric in metrics]
            values += values[:1]  # Complete the circle
            
            ax.plot(angles, values, 'o-', linewidth=2, label=model, color=color)
            ax.fill(angles, values, alpha=0.1, color=color)
        
        # Add metric labels
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels([m.upper() for m in metrics])
        ax.set_ylim(0, 1)
        ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
        ax.grid(True)
        
        plt.title('2-gram Classification Performance Radar Chart', 
                 size=14, fontweight='bold', pad=20)
        plt.legend(bbox_to_anchor=(1.1, 1.0))
        plt.tight_layout()
        plt.savefig('2gram_performance_radar.pdf', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_memory_efficiency_comparison(self, results):
        """Plot training time vs performance for memory efficiency analysis"""
        models = list(results.keys())
        training_times = [results[model]['training_time'] for model in models]
        f1_scores = [results[model]['f1_score'] for model in models]
        
        plt.figure(figsize=(12, 8))
        scatter = plt.scatter(training_times, f1_scores, s=100, alpha=0.7, 
                            c=range(len(models)), cmap='viridis')
        
        # Add model labels
        for i, model in enumerate(models):
            plt.annotate(model, (training_times[i], f1_scores[i]),
                        xytext=(5, 5), textcoords='offset points',
                        fontsize=9, fontweight='bold')
        
        plt.xlabel('Training Time (seconds)', fontsize=12, fontweight='bold')
        plt.ylabel('F1-Score', fontsize=12, fontweight='bold')
        plt.title('2-gram Classification: Training Time vs Performance', 
                 fontsize=14, fontweight='bold')
        plt.grid(True, alpha=0.3)
        plt.colorbar(scatter, label='Model Index')
        plt.tight_layout()
        plt.savefig('2gram_efficiency_analysis.pdf', dpi=300, bbox_inches='tight')
        plt.close()

def generate_2gram_summary_report(results, processor):
    """Generate comprehensive 2-gram specific summary report"""
    summary_lines = []
    summary_lines.append("2-GRAM CLASSIFICATION RESULTS SUMMARY")
    summary_lines.append("=" * 60)
    summary_lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    summary_lines.append(f"Original Features: ~1.4M")
    summary_lines.append(f"Reduced Features: {processor.max_features}")
    summary_lines.append(f"Classes: {len(processor.label_encoder.classes_)}")
    summary_lines.append("")
    
    # Individual model results
    for model_name, result in results.items():
        summary_lines.append(f"{model_name.upper()}")
        summary_lines.append("-" * 40)
        summary_lines.append(f"Accuracy:    {result['accuracy']:.4f}")
        summary_lines.append(f"Precision:   {result['precision']:.4f}")
        summary_lines.append(f"Recall:      {result['recall']:.4f}")
        summary_lines.append(f"F1-Score:    {result['f1_score']:.4f}")
        summary_lines.append(f"Training:    {result['training_time']:.2f}s")
        summary_lines.append(f"Prediction:  {result['prediction_time']:.2f}s")
        summary_lines.append("")
    
    # Comparative analysis
    summary_lines.append("COMPARATIVE ANALYSIS")
    summary_lines.append("-" * 40)
    
    if results:
        best_accuracy = max(results.values(), key=lambda x: x['accuracy'])
        best_f1 = max(results.values(), key=lambda x: x['f1_score'])
        fastest_training = min(results.values(), key=lambda x: x['training_time'])
        
        best_accuracy_model = [k for k, v in results.items() if v == best_accuracy][0]
        best_f1_model = [k for k, v in results.items() if v == best_f1][0]
        fastest_model = [k for k, v in results.items() if v == fastest_training][0]
        
        summary_lines.append(f"Best Accuracy: {best_accuracy_model} ({best_accuracy['accuracy']:.4f})")
        summary_lines.append(f"Best F1-Score: {best_f1_model} ({best_f1['f1_score']:.4f})")
        summary_lines.append(f"Fastest Training: {fastest_model} ({fastest_training['training_time']:.2f}s)")
        summary_lines.append(f"Most Memory Efficient: Linear SVM & SGD Classifier")
    
    # Write to file
    with open('2gram_classification_summary.txt', 'w') as f:
        f.write('\n'.join(summary_lines))
    
    logging.info("2-gram summary report generated: 2gram_classification_summary.txt")

def main():
    """Main 2-gram classification pipeline"""
    parser = argparse.ArgumentParser(description='2-gram Malware Classification')
    parser.add_argument('input_file', help='Input HDF5 file (e.g., 2gramdata.h5)')
    parser.add_argument('--max-features', type=int, default=500,
                       help='Maximum number of features after dimensionality reduction (default: 500)')
    parser.add_argument('--test-size', type=float, default=0.3,
                       help='Test set size proportion (default: 0.3)')
    
    args = parser.parse_args()
    
    # Setup logging
    log_filename = setup_logging()
    logging.info(f"Starting 2-gram classification pipeline")
    logging.info(f"Input file: {args.input_file}")
    logging.info(f"Max features: {args.max_features}")
    logging.info(f"Test size: {args.test_size}")
    
    try:
        # Initialize ultra memory-efficient processor
        processor = UltraSparseDataProcessor(
            max_features=args.max_features,
            test_size=args.test_size,
            random_state=42
        )
        
        # Load 2-gram data with minimal memory footprint
        X_sparse, y = processor.load_sparse_data(args.input_file)
        
        # Preprocess with memory efficiency
        X_train, X_test, y_train, y_test = processor.preprocess_data(X_sparse, y)
        
        # Train memory-efficient classifiers
        classifier_manager = MemoryEfficientClassifier(processor.label_encoder)
        results = classifier_manager.train_memory_efficient_models(X_train, y_train, X_test, y_test)
        
        # Generate advanced visualizations
        viz = AdvancedVisualization(processor.label_encoder)
        
        # Create confusion matrices for each model
        for model_name, result in results.items():
            viz.plot_compact_confusion_matrix(result['y_true'], result['y_pred'], model_name)
        
        # Create comparative visualizations
        if results:
            viz.plot_performance_radar(results)
            viz.plot_memory_efficiency_comparison(results)
        
        # Generate comprehensive summary
        generate_2gram_summary_report(results, processor)
        
        logging.info(f"\n{'='*60}")
        logging.info("2-GRAM CLASSIFICATION PIPELINE COMPLETED SUCCESSFULLY")
        logging.info(f"{'='*60}")
        logging.info(f"Log file: {log_filename}")
        logging.info(f"Summary report: 2gram_classification_summary.txt")
        logging.info(f"Visualizations saved as PDF files")
        logging.info(f"Memory efficiency: Aggressive feature reduction applied")
        
    except Exception as e:
        logging.error(f"Error in 2-gram classification pipeline: {e}")
        import traceback
        logging.error(traceback.format_exc())
        raise

if __name__ == "__main__":
    main()