# -*- coding: utf-8 -*-
"""Optimized 1-gram Feature Extraction with HDF5 Output"""

import logging
import time
import os
import pandas as pd
from multiprocessing import Pool
import glob
from collections import Counter
import argparse
import sys
import numpy as np
from scipy import sparse
import tables  # For HDF5 support

class OptimizedOneGramFeatureExtractor:
    """Optimized 1-gram feature extractor with HDF5 output"""
    
    def __init__(self, input_dir="raw_opcodes", output_dir="1-gram_data", 
                 combined_output="1gramdata.h5", num_workers=4):
        """
        Initialize the optimized 1-gram feature extractor.
        
        Args:
            input_dir: Directory containing raw opcode files
            output_dir: Directory to store individual 1-gram feature files
            combined_output: Filename for combined HDF5 output
            num_workers: Number of parallel workers
        """
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.combined_output = combined_output
        self.num_workers = num_workers
        
        # Initialize statistics
        self.stats = {
            'input_files_count': 0,
            'output_files_count': 0,
            'successful_extractions': 0,
            'failed_extractions': 0,
            'start_time': 0,
            'total_processing_time': 0,
            'unique_opcodes_count': 0,
            'unique_mitre_ids_count': 0
        }
        
        # Setup logging
        self._setup_logging()
    
    def _setup_logging(self):
        """Configure logging settings"""
        logging.basicConfig(
            filename='optimized_1gram_processing.log', 
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            filemode='w'
        )
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        logging.getLogger().addHandler(console_handler)
    
    def extract_mitre_id(self, filename):
        """
        Extract MITRE ID from filename.
        Format: G0010_Turla_Russia_G0010_Turla_Russia_0ce9aadf6a3ffd85d6189590ece148b2f9d69e0ce1c2b8eb61361eb8d0f98571.opcode
        Returns: G0010 (string before first '_')
        """
        try:
            # Remove file extension and get the base name
            base_name = os.path.splitext(filename)[0]
            # Split by underscore and take first part
            mitre_id = base_name.split('_')[0]
            return mitre_id
        except Exception as e:
            logging.warning(f"Could not extract MITRE ID from {filename}: {e}")
            return filename  # Fallback to original filename
    
    def extract_1_grams_fast(self, content, min_opcode_length=2):
        """
        Optimized 1-gram extraction using efficient string operations.
        
        Args:
            content: Raw opcode content as string
            min_opcode_length: Minimum length for valid opcodes
            
        Returns:
            Dictionary with opcode counts
        """
        try:
            # Fast split and filter using list comprehension
            opcodes = [opcode for opcode in content.split() 
                      if opcode and len(opcode) >= min_opcode_length]
            
            # Use Counter for fast frequency counting
            return dict(Counter(opcodes))
            
        except Exception as e:
            logging.error(f"Error extracting 1-grams: {e}")
            return {}
    
    def process_single_file_fast(self, file_path):
        """
        Fast processing of a single file with minimal I/O operations.
        
        Args:
            file_path: Path to the opcode file
            
        Returns:
            Tuple (success, mitre_id, opcode_counts, original_filename)
        """
        try:
            original_filename = os.path.basename(file_path)
            mitre_id = self.extract_mitre_id(original_filename)
            
            # Fast file reading
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            if not content.strip():
                return False, mitre_id, {}, original_filename
            
            # Fast extraction
            opcode_counts = self.extract_1_grams_fast(content)
            
            if not opcode_counts:
                return False, mitre_id, {}, original_filename
            
            return True, mitre_id, opcode_counts, original_filename
                
        except Exception as e:
            logging.error(f"Error processing {file_path}: {e}")
            original_filename = os.path.basename(file_path)
            mitre_id = self.extract_mitre_id(original_filename)
            return False, mitre_id, {}, original_filename
    
    def process_and_store_files_parallel(self):
        """
        Process all files in parallel and store results efficiently.
        
        Returns:
            Dictionary of (mitre_id, original_filename) -> opcode_counts
        """
        # Get list of opcode files
        opcode_files = glob.glob(os.path.join(self.input_dir, "*"))
        opcode_files = [f for f in opcode_files if os.path.isfile(f)]
        
        if not opcode_files:
            logging.warning(f"No files found in {self.input_dir}")
            return {}
        
        self.stats['input_files_count'] = len(opcode_files)
        self.stats['start_time'] = time.time()
        
        logging.info(f"Found {len(opcode_files)} files to process")
        logging.info(f"Starting optimized parallel processing with {self.num_workers} workers")
        
        # Process files in parallel
        with Pool(processes=self.num_workers) as pool:
            results = pool.map(self.process_single_file_fast, opcode_files)
        
        # Process results and store files
        all_opcode_counts = {}
        successful_files = []
        unique_mitre_ids = set()
        
        for success, mitre_id, opcode_counts, original_filename in results:
            if success and opcode_counts:
                self.stats['successful_extractions'] += 1
                unique_mitre_ids.add(mitre_id)
                
                # Use (mitre_id, original_filename) as key to allow duplicates
                key = (mitre_id, original_filename)
                all_opcode_counts[key] = opcode_counts
                successful_files.append((mitre_id, original_filename, opcode_counts))
                
                logging.info(f"Successfully processed: {original_filename} -> MITRE ID: {mitre_id}")
            else:
                self.stats['failed_extractions'] += 1
                logging.error(f"Failed to process: {original_filename} (MITRE ID: {mitre_id})")
        
        # Batch write output files
        self._batch_write_output_files(successful_files)
        
        self.stats['output_files_count'] = self.stats['successful_extractions']
        self.stats['unique_mitre_ids_count'] = len(unique_mitre_ids)
        
        logging.info(f"Parallel processing completed: {self.stats['successful_extractions']} successful, "
                    f"{self.stats['failed_extractions']} failed")
        logging.info(f"Unique MITRE IDs found: {self.stats['unique_mitre_ids_count']}")
        
        return all_opcode_counts
    
    def _batch_write_output_files(self, successful_files):
        """
        Batch write output files to reduce I/O overhead.
        
        Args:
            successful_files: List of (mitre_id, original_filename, opcode_counts) tuples
        """
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        for mitre_id, original_filename, opcode_counts in successful_files:
            # Use original filename for individual files to avoid conflicts
            output_path = os.path.join(self.output_dir, f"{original_filename}_1gram.txt")
            try:
                with open(output_path, 'w') as f:
                    f.write(f"# Original filename: {original_filename}\n")
                    f.write(f"# MITRE ID: {mitre_id}\n")
                    for opcode, count in sorted(opcode_counts.items()):
                        f.write(f"{opcode}\t{count}\n")
                logging.debug(f"Successfully wrote 1-gram data to {output_path}")
            except Exception as e:
                logging.error(f"Error writing 1-gram data for {original_filename}: {e}")
    
    def create_sparse_feature_matrix(self, all_opcode_counts):
        """
        Create sparse feature matrix using scipy sparse matrices.
        
        Args:
            all_opcode_counts: Dictionary of (mitre_id, filename) -> opcode counts
            
        Returns:
            tuple: (sparse_matrix, row_metadata, opcode_vocabulary)
        """
        if not all_opcode_counts:
            logging.warning("No opcode counts to combine")
            return None, [], []
        
        try:
            # Get all unique opcodes efficiently
            all_unique_opcodes = set()
            for counts in all_opcode_counts.values():
                all_unique_opcodes.update(counts.keys())
            
            self.stats['unique_opcodes_count'] = len(all_unique_opcodes)
            logging.info(f"Found {len(all_unique_opcodes)} unique opcodes across all files")
            
            # Convert to sorted lists for consistent indexing
            row_keys = sorted(all_opcode_counts.keys())  # (mitre_id, filename) tuples
            opcode_vocabulary = sorted(all_unique_opcodes)
            
            # Create mapping dictionaries for fast lookup
            key_to_idx = {key: idx for idx, key in enumerate(row_keys)}
            opcode_to_idx = {opcode: idx for idx, opcode in enumerate(opcode_vocabulary)}
            
            # Build sparse matrix data
            data = []
            row_indices = []
            col_indices = []
            
            for key, counts in all_opcode_counts.items():
                row_idx = key_to_idx[key]
                for opcode, count in counts.items():
                    if opcode in opcode_to_idx:  # Should always be true
                        col_idx = opcode_to_idx[opcode]
                        data.append(count)
                        row_indices.append(row_idx)
                        col_indices.append(col_idx)
            
            # Create sparse matrix
            sparse_matrix = sparse.csr_matrix(
                (data, (row_indices, col_indices)),
                shape=(len(row_keys), len(opcode_vocabulary)),
                dtype=np.int32
            )
            
            # Create row metadata
            row_metadata = []
            for mitre_id, filename in row_keys:
                row_metadata.append({
                    'mitre_id': mitre_id,
                    'filename': filename
                })
            
            logging.info(f"Created sparse matrix with shape: {sparse_matrix.shape}")
            logging.info(f"Sparse matrix memory usage: {sparse_matrix.data.nbytes / 1024 / 1024:.2f} MB")
            
            return sparse_matrix, row_metadata, opcode_vocabulary
            
        except Exception as e:
            logging.error(f"Error creating sparse feature matrix: {e}")
            return None, [], []
    
    def save_sparse_hdf5(self, sparse_matrix, row_metadata, opcode_vocabulary):
        """
        Save sparse matrix to HDF5 format with metadata.
        
        Args:
            sparse_matrix: scipy sparse matrix
            row_metadata: List of dictionaries with MITRE IDs and filenames
            opcode_vocabulary: List of opcode names
            
        Returns:
            bool: Success status
        """
        if sparse_matrix is None:
            logging.warning("No data to save to HDF5")
            return False
        
        try:
            # Convert to COO format for efficient storage
            sparse_coo = sparse_matrix.tocoo()
            
            # Prepare metadata arrays
            mitre_ids = [item['mitre_id'] for item in row_metadata]
            filenames = [item['filename'] for item in row_metadata]
            
            # Save to HDF5
            with tables.open_file(self.combined_output, 'w') as h5file:
                # Store sparse matrix data
                h5file.create_array(h5file.root, 'data', sparse_coo.data)
                h5file.create_array(h5file.root, 'row', sparse_coo.row)
                h5file.create_array(h5file.root, 'col', sparse_coo.col)
                h5file.create_array(h5file.root, 'shape', sparse_coo.shape)
                
                # Store metadata
                h5file.create_array(h5file.root, 'mitre_ids', np.array(mitre_ids, dtype='S'))
                h5file.create_array(h5file.root, 'filenames', np.array(filenames, dtype='S'))
                h5file.create_array(h5file.root, 'opcode_vocabulary', np.array(opcode_vocabulary, dtype='S'))
                
                # Store attributes
                h5file.root._v_attrs.creation_date = time.ctime()
                h5file.root._v_attrs.num_samples = len(row_metadata)
                h5file.root._v_attrs.num_features = len(opcode_vocabulary)
                h5file.root._v_attrs.sparse_format = 'COO'
                h5file.root._v_attrs.unique_mitre_ids = self.stats['unique_mitre_ids_count']
            
            logging.info(f"Successfully saved sparse feature matrix to {self.combined_output}")
            
            # Create summary statistics
            self._create_summary_statistics_hdf5(sparse_matrix, row_metadata, opcode_vocabulary)
            
            return True
            
        except Exception as e:
            logging.error(f"Error saving HDF5 file: {e}")
            return False
    
    def _create_summary_statistics_hdf5(self, sparse_matrix, row_metadata, opcode_vocabulary):
        """Create summary statistics for HDF5 output"""
        try:
            stats_file = "1gramdata_summary.txt"
            
            # Calculate some basic statistics
            total_opcodes = sparse_matrix.sum()
            density = sparse_matrix.nnz / (sparse_matrix.shape[0] * sparse_matrix.shape[1]) * 100
            
            # Count MITRE ID distribution
            mitre_id_counts = Counter([item['mitre_id'] for item in row_metadata])
            
            with open(stats_file, 'w') as f:
                f.write("OPTIMIZED 1-GRAM DATA SUMMARY (HDF5 FORMAT)\n")
                f.write("=" * 60 + "\n")
                f.write(f"Total files processed: {len(row_metadata)}\n")
                f.write(f"Unique MITRE IDs: {self.stats['unique_mitre_ids_count']}\n")
                f.write(f"Total unique opcodes: {len(opcode_vocabulary)}\n")
                f.write(f"Feature matrix shape: {sparse_matrix.shape}\n")
                f.write(f"Total opcode occurrences: {total_opcodes:,}\n")
                f.write(f"Matrix density: {density:.6f}%\n")
                f.write(f"Non-zero elements: {sparse_matrix.nnz:,}\n")
                f.write(f"Sparse matrix size: {sparse_matrix.data.nbytes / 1024 / 1024:.2f} MB\n")
                f.write(f"HDF5 file: {self.combined_output}\n")
                f.write(f"Generated on: {time.ctime()}\n\n")
                
                f.write("MITRE ID DISTRIBUTION:\n")
                f.write("-" * 60 + "\n")
                for mitre_id, count in mitre_id_counts.most_common(20):
                    f.write(f"{mitre_id:<10} : {count:>4} files\n")
                
                f.write("\nTOP 20 MOST FREQUENT OPCODES ACROSS ALL FILES:\n")
                f.write("-" * 60 + "\n")
                
                # Calculate opcode frequencies
                opcode_frequencies = np.array(sparse_matrix.sum(axis=0)).flatten()
                top_indices = np.argsort(opcode_frequencies)[-20:][::-1]
                
                for i, idx in enumerate(top_indices):
                    opcode = opcode_vocabulary[idx]
                    count = int(opcode_frequencies[idx])
                    f.write(f"{i+1:2d}. {opcode:<15} : {count:>8,}\n")
            
            logging.info(f"Summary statistics saved to {stats_file}")
            
        except Exception as e:
            logging.error(f"Error creating summary statistics: {e}")
    
    def generate_report(self):
        """Generate and display final processing report"""
        self.stats['total_processing_time'] = time.time() - self.stats['start_time']
        
        # Calculate success rate
        if self.stats['input_files_count'] > 0:
            success_rate = (self.stats['successful_extractions'] / self.stats['input_files_count']) * 100
        else:
            success_rate = 0
        
        # Format duration
        minutes, seconds = divmod(self.stats['total_processing_time'], 60)
        duration_str = f"{int(minutes)} minutes and {seconds:.2f} seconds"
        
        # Print report
        print("\n" + "="*60)
        print("    OPTIMIZED 1-GRAM FEATURE EXTRACTION REPORT (HDF5)")
        print("="*60)
        print(f"Input Directory: {self.input_dir}")
        print(f"Output Directory: {self.output_dir}")
        print(f"Combined Output: {self.combined_output}")
        print(f"Number of Workers: {self.num_workers}")
        print("-"*60)
        print(f"Total input files: {self.stats['input_files_count']}")
        print(f"Successful extractions: {self.stats['successful_extractions']}")
        print(f"Failed extractions: {self.stats['failed_extractions']}")
        print(f"Success rate: {success_rate:.2f}%")
        print(f"Output files created: {self.stats['output_files_count']}")
        print(f"Unique MITRE IDs: {self.stats['unique_mitre_ids_count']}")
        print(f"Unique opcodes found: {self.stats['unique_opcodes_count']}")
        print(f"Total processing time: {self.stats['total_processing_time']:.2f} seconds")
        print(f"Processing duration: {duration_str}")
        print("="*60)
        
        logging.info(f"OPTIMIZED PROCESSING COMPLETED: {self.stats['successful_extractions']}/"
                    f"{self.stats['input_files_count']} files processed successfully")
    
    def run_extraction(self):
        """
        Run the optimized 1-gram feature extraction pipeline with HDF5 output.
        
        Returns:
            bool: Success status
        """
        logging.info("Starting OPTIMIZED 1-gram feature extraction pipeline with HDF5 output")
        
        try:
            # Step 1: Process files in parallel (with storage)
            all_opcode_counts = self.process_and_store_files_parallel()
            
            # Step 2: Create sparse feature matrix
            sparse_matrix, row_metadata, opcode_vocabulary = self.create_sparse_feature_matrix(all_opcode_counts)
            
            # Step 3: Save to HDF5
            if sparse_matrix is not None:
                hdf5_success = self.save_sparse_hdf5(sparse_matrix, row_metadata, opcode_vocabulary)
                if hdf5_success:
                    logging.info(f"SUCCESS: Sparse 1-gram data saved to {self.combined_output}")
                else:
                    logging.error(f"FAILED: Could not save HDF5 data to {self.combined_output}")
            
            # Step 4: Generate report
            self.generate_report()
            
            return sparse_matrix is not None and hdf5_success
            
        except Exception as e:
            logging.error(f"Error in optimized extraction pipeline: {e}")
            self.generate_report()
            return False

def main():
    """Main function to handle command line arguments"""
    parser = argparse.ArgumentParser(description='Optimized 1-gram feature extraction from opcode files with HDF5 output')
    parser.add_argument('--number_of_workers', type=int, default=4,
                       help='Number of parallel workers (default: 4)')
    
    args = parser.parse_args()
    
    # Validate number of workers
    if args.number_of_workers <= 0:
        print("Error: Number of workers must be positive")
        sys.exit(1)
    
    print(f"Starting OPTIMIZED 1-gram feature extraction with {args.number_of_workers} workers...")
    print("Output format: HDF5 (sparse matrix)")
    print("MITRE ID handling: Multiple files can have same MITRE ID")
    
    # Check if input directory exists
    if not os.path.exists("raw_opcodes"):
        print("Error: 'raw_opcodes' directory not found")
        print("Please ensure opcode files are stored in 'raw_opcodes' folder")
        sys.exit(1)
    
    # Initialize and run optimized extractor
    extractor = OptimizedOneGramFeatureExtractor(
        input_dir="raw_opcodes",
        output_dir="1-gram_data", 
        combined_output="1gramdata.h5",  # Changed to .h5
        num_workers=args.number_of_workers
    )
    
    # Run the extraction
    start_time = time.time()
    success = extractor.run_extraction()
    total_time = time.time() - start_time
    
    # Display results
    if success:
        print(f"\n✓ SUCCESS: Sparse feature matrix saved to: 1gramdata.h5")
        print(f"✓ Individual feature files saved to: 1-gram_data/")
        print(f"✓ Processing log saved to: optimized_1gram_processing.log")
        print(f"✓ Summary statistics saved to: 1gramdata_summary.txt")
        print(f"✓ Total execution time: {total_time:.2f} seconds")
        print(f"✓ MITRE ID distribution saved in summary file")
    else:
        print("\n✗ Extraction failed. Check optimized_1gram_processing.log for details.")
        sys.exit(1)

if __name__ == "__main__":
    main()