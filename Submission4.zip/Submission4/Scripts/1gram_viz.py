#!/usr/bin/env python3
"""
1-gram Malware Opcode Visualization
Usage: python 1gram_viz.py --input 1gramdata.h5
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import h5py
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from scipy.sparse import coo_matrix, csr_matrix
import os
import argparse

def load_1gram_data(h5_file_path, max_samples=1512):
    """
    Load 1-gram data from HDF5 file with sparse matrix support
    """
    print(f"Loading data from {h5_file_path}...")
    
    with h5py.File(h5_file_path, 'r') as f:
        # Explore available datasets
        print("Available datasets in HDF5 file:")
        for key in f.keys():
            dataset = f[key]
            print(f"  - {key}: {dataset.shape} (dtype: {dataset.dtype})")
        
        # Check if we have sparse matrix data (COO format)
        if all(key in f.keys() for key in ['row', 'col', 'data', 'shape']):
            print("Detected sparse matrix format (COO)...")
            
            # Load sparse matrix components
            row = f['row'][:]
            col = f['col'][:]
            data = f['data'][:]
            shape = f['shape'][:]
            
            print(f"Sparse matrix shape: {shape}")
            print(f"Non-zero elements: {len(data)}")
            
            # Create sparse matrix
            sparse_features = coo_matrix((data, (row, col)), shape=shape)
            
            # Convert to CSR format for efficient slicing
            sparse_features_csr = sparse_features.tocsr()
            
            # Use only first max_samples to manage memory
            n_samples = min(max_samples, shape[0])
            print(f"Using first {n_samples} samples for visualization...")
            
            # Extract subset and convert to dense
            features = sparse_features_csr[:n_samples, :].toarray()
                
            print(f"Converted to dense features: {features.shape}")
        
        else:
            # Try to find dense features
            for key in f.keys():
                if len(f[key].shape) == 2:
                    features = f[key][:]
                    print(f"Using dataset '{key}' as features: {features.shape}")
                    break
            else:
                raise ValueError("Could not find feature data in HDF5 file")
        
        # Load filenames
        if 'filenames' in f.keys():
            filenames = f['filenames'][:]
            # Convert bytes to strings if needed
            if isinstance(filenames[0], bytes):
                filenames = [f.decode('utf-8') for f in filenames]
            # Take only the samples we're using
            filenames = filenames[:features.shape[0]]
        else:
            filenames = np.array([f'sample_{i}' for i in range(features.shape[0])])
        
        # Load or create labels
        if 'mitre_ids' in f.keys():
            labels = f['mitre_ids'][:]
            # Convert bytes to strings if needed
            if isinstance(labels[0], bytes):
                labels = [label.decode('utf-8') for label in labels]
            # Take only the samples we're using
            labels = labels[:features.shape[0]]
            print(f"Using MITRE IDs as labels")
        else:
            # Create labels from filenames or use 'Unknown'
            labels = []
            for filename in filenames:
                filename_lower = filename.lower()
                if 'trojan' in filename_lower:
                    labels.append('Trojan')
                elif 'ransom' in filename_lower:
                    labels.append('Ransomware')
                elif 'virus' in filename_lower:
                    labels.append('Virus')
                elif 'worm' in filename_lower:
                    labels.append('Worm')
                elif 'backdoor' in filename_lower:
                    labels.append('Backdoor')
                elif 'spyware' in filename_lower:
                    labels.append('Spyware')
                elif 'adware' in filename_lower:
                    labels.append('Adware')
                else:
                    labels.append('Unknown')
            labels = np.array(labels)
            print("Created labels from filenames")
        
        # Load feature names (opcode vocabulary)
        if 'opcode_vocabulary' in f.keys():
            feature_names = f['opcode_vocabulary'][:]
            # Convert bytes to strings if needed
            if isinstance(feature_names[0], bytes):
                feature_names = [name.decode('utf-8') for name in feature_names]
            print(f"Loaded {len(feature_names)} opcode features")
        else:
            feature_names = np.array([f'opcode_{i}' for i in range(features.shape[1])])
    
    print(f"Final dataset: {features.shape[0]} samples, {features.shape[1]} features")
    print(f"Label distribution:")
    unique_labels, counts = np.unique(labels, return_counts=True)
    for label, count in zip(unique_labels, counts):
        print(f"  - {label}: {count} samples")
    
    return features, labels, filenames, feature_names

def create_publication_visualization(features, labels, output_file="1gram_tsne_visualization.pdf"):
    """
    Create publication-quality t-SNE visualization
    """
    
    # Set professional style
    plt.style.use('default')
    sns.set_palette("husl")
    plt.rcParams['font.family'] = 'DejaVu Sans'
    plt.rcParams['font.size'] = 10
    plt.rcParams['axes.linewidth'] = 1.2
    
    # Create figure with subplots
    fig = plt.figure(figsize=(20, 8))
    gs = fig.add_gridspec(2, 3, height_ratios=[3, 1])
    
    # Main visualization subplots
    ax1 = fig.add_subplot(gs[0, :2])  # t-SNE plot
    ax2 = fig.add_subplot(gs[0, 2])   # Feature importance
    ax3 = fig.add_subplot(gs[1, :])   # Statistics
    
    fig.suptitle('t-SNE Visualization of 1-gram Opcode Features', 
                 fontsize=16, fontweight='bold', y=0.98)
    
    # Preprocessing
    print("Preprocessing data...")
    scaler = StandardScaler()
    features_standardized = scaler.fit_transform(features)
    
    # Perform t-SNE with scikit-learn 1.7.2 parameters
    print("Running t-SNE...")
    tsne = TSNE(n_components=2, 
                random_state=42, 
                perplexity=min(30, len(features) - 1),
                max_iter=1000,  # Correct parameter for scikit-learn >= 1.2
                init='pca',
                learning_rate='auto',
                verbose=1)
    
    tsne_results = tsne.fit_transform(features_standardized)
    
    # Create DataFrame for plotting
    tsne_df = pd.DataFrame({
        'TSNE1': tsne_results[:, 0],
        'TSNE2': tsne_results[:, 1],
        'Label': labels
    })
    
    # Plot 1: Main t-SNE visualization
    unique_labels = np.unique(labels)
    colors = plt.cm.Set3(np.linspace(0, 1, len(unique_labels)))
    
    for i, label in enumerate(unique_labels):
        mask = tsne_df['Label'] == label
        if mask.sum() > 0:  # Only plot if we have samples for this label
            ax1.scatter(tsne_df.loc[mask, 'TSNE1'], 
                       tsne_df.loc[mask, 'TSNE2'],
                       c=[colors[i]], 
                       label=f'{label} ({mask.sum()})', 
                       alpha=0.8, 
                       s=50,
                       edgecolors='white',
                       linewidth=0.5,
                       zorder=3)
    
    ax1.set_xlabel('t-SNE Component 1', fontsize=12, fontweight='bold')
    ax1.set_ylabel('t-SNE Component 2', fontsize=12, fontweight='bold')
    ax1.set_title('Malware Family Clustering', fontsize=14, fontweight='bold')
    ax1.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=9)
    ax1.grid(True, alpha=0.3, linestyle='--')
    
    # Plot 2: Feature variance (most important features)
    feature_variance = np.var(features_standardized, axis=0)
    top_features_idx = np.argsort(feature_variance)[-10:]  # Top 10 most variable features
    
    ax2.barh(range(len(top_features_idx)), feature_variance[top_features_idx],
            color='skyblue', alpha=0.7)
    ax2.set_yticks(range(len(top_features_idx)))
    ax2.set_yticklabels([f'Feature {i}' for i in top_features_idx], fontsize=8)
    ax2.set_xlabel('Variance', fontsize=10, fontweight='bold')
    ax2.set_title('Top 10 Most Variable Features', fontsize=12, fontweight='bold')
    ax2.grid(True, alpha=0.3, axis='x')
    
    # Plot 3: Family distribution statistics
    family_counts = pd.Series(labels).value_counts()
    family_colors_plot = []
    for fam in family_counts.index:
        if fam in unique_labels:
            idx = np.where(unique_labels == fam)[0][0]
            family_colors_plot.append(colors[idx])
        else:
            family_colors_plot.append('gray')
    
    bars = ax3.bar(range(len(family_counts)), family_counts.values, 
                  color=family_colors_plot, alpha=0.7)
    ax3.set_xlabel('Malware Family', fontsize=10, fontweight='bold')
    ax3.set_ylabel('Sample Count', fontsize=10, fontweight='bold')
    ax3.set_title('Dataset Distribution by Family', fontsize=12, fontweight='bold')
    ax3.set_xticks(range(len(family_counts)))
    ax3.set_xticklabels(family_counts.index, rotation=45, ha='right', fontsize=8)
    
    # Add value labels on bars
    for bar, count in zip(bars, family_counts.values):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height,
                f'{count}', ha='center', va='bottom', fontsize=8, fontweight='bold')
    
    # Add comprehensive annotations
    annotation_text = f"""
Analysis Summary:
• Total Samples: {len(features):,}
• Features: {features.shape[1]:,}
• Families: {len(unique_labels)}
• t-SNE KL Divergence: {tsne.kl_divergence_:.4f}
• Output: {output_file}
    """
    
    fig.text(0.02, 0.02, annotation_text, fontsize=9,
            bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgray", alpha=0.8),
            verticalalignment='bottom')
    
    # Adjust layout and save
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight', 
                facecolor='white', edgecolor='none')
    
    print(f"Visualization saved as: {output_file}")
    
    return tsne_results

def create_additional_visualizations(features, labels, tsne_results):
    """
    Create additional visualizations for comprehensive analysis
    """
    
    # Visualization 2: Density plot
    plt.figure(figsize=(10, 8))
    
    tsne_df = pd.DataFrame({
        'TSNE1': tsne_results[:, 0],
        'TSNE2': tsne_results[:, 1],
        'Label': labels
    })
    
    # Create a scatter plot with density coloring
    scatter = plt.scatter(tsne_df['TSNE1'], tsne_df['TSNE2'],
                         c=tsne_df['TSNE1'], cmap='viridis',
                         alpha=0.6, s=40)
    
    plt.xlabel('t-SNE Component 1', fontsize=12, fontweight='bold')
    plt.ylabel('t-SNE Component 2', fontsize=12, fontweight='bold')
    plt.title('1-gram Feature Density Visualization', fontsize=14, fontweight='bold')
    plt.colorbar(scatter, label='t-SNE Component 1 Value')
    plt.grid(True, alpha=0.3)
    
    plt.savefig('1gram_density_plot.pdf', dpi=300, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    
    # Visualization 3: Simple cluster plot
    plt.figure(figsize=(12, 8))
    
    unique_labels = np.unique(labels)
    for label in unique_labels:
        mask = tsne_df['Label'] == label
        if mask.sum() > 0:
            plt.scatter(tsne_df.loc[mask, 'TSNE1'], tsne_df.loc[mask, 'TSNE2'],
                       label=f'{label} ({mask.sum()})', alpha=0.7, s=50)
    
    plt.xlabel('t-SNE Component 1', fontsize=12, fontweight='bold')
    plt.ylabel('t-SNE Component 2', fontsize=12, fontweight='bold')
    plt.title('1-gram Opcode Clustering', fontsize=14, fontweight='bold')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.savefig('1gram_simple_clusters.pdf', dpi=300, bbox_inches='tight',
                facecolor='white', edgecolor='none')

def main():
    """Main function to run the visualization"""
    
    # Set up argument parser
    parser = argparse.ArgumentParser(description='Visualize 1-gram malware opcode data')
    parser.add_argument('--input', default='1gramdata.h5', 
                       help='Input HDF5 file (default: 1gramdata.h5)')
    parser.add_argument('--output', default='1gram_tsne_visualization.pdf',
                       help='Output PDF file (default: 1gram_tsne_visualization.pdf)')
    parser.add_argument('--max-samples', type=int, default=1512,
                       help='Maximum number of samples to use (default: 1000)')
    
    args = parser.parse_args()
    
    # Check if input file exists
    if not os.path.exists(args.input):
        print(f"Error: Input file '{args.input}' not found!")
        print("Please ensure the HDF5 file is in the current directory")
        print("Current directory contents:")
        for file in os.listdir('.'):
            if file.endswith('.h5') or file.endswith('.hdf5'):
                print(f"  - {file}")
        return
    
    try:
        # Load data
        features, labels, filenames, feature_names = load_1gram_data(args.input, args.max_samples)
        
        # Create main visualization
        print("Creating main visualization...")
        tsne_results = create_publication_visualization(features, labels, args.output)
        
        # Create additional visualizations
        print("Creating additional visualizations...")
        create_additional_visualizations(features, labels, tsne_results)
        
        # Print summary statistics
        print("\n" + "="*50)
        print("VISUALIZATION COMPLETE")
        print("="*50)
        print(f"Generated files:")
        print(f"  - {args.output} (main visualization)")
        print(f"  - 1gram_density_plot.pdf")
        print(f"  - 1gram_simple_clusters.pdf")
        print(f"\nDataset statistics:")
        print(f"  - Samples: {len(features):,}")
        print(f"  - Features: {features.shape[1]:,}")
        print(f"  - Malware families: {len(np.unique(labels))}")
        print(f"  - Family distribution:")
        for label, count in pd.Series(labels).value_counts().items():
            print(f"      {label}: {count} samples")
        
    except Exception as e:
        print(f"Error during visualization: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()