#!/usr/bin/env python3
"""
1-gram Malware Classification with Memory-Efficient Sparse Processing
Usage: python 1gramdata_classification.py 1gramdata.h5 [--max-features 1000] [--test-size 0.3]
"""

import numpy as np
import pandas as pd
import h5py
import time
import logging
import argparse
from datetime import datetime
from pathlib import Path

# Scikit-learn imports with sparse matrix support
from sklearn.model_selection import train_test_split, StratifiedShuffleSplit
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.utils.class_weight import compute_class_weight

# Classifiers
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier

# Metrics and evaluation
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                           f1_score, confusion_matrix, classification_report)

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap

# Configure logging
def setup_logging():
    """Setup comprehensive logging"""
    log_filename = f"classification_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename),
            logging.StreamHandler()
        ]
    )
    return log_filename

class SparseDataProcessor:
    """Memory-efficient processor for sparse malware data"""
    
    def __init__(self, max_features=1000, test_size=0.3, random_state=42):
        self.max_features = max_features
        self.test_size = test_size
        self.random_state = random_state
        self.label_encoder = LabelEncoder()
        self.feature_selector = None
        self.scaler = StandardScaler(with_mean=False)  # Important for sparse data
        
    def load_sparse_data(self, h5_file_path):
        """Load sparse data from HDF5 file without converting to dense"""
        logging.info(f"Loading data from {h5_file_path}")
        
        with h5py.File(h5_file_path, 'r') as f:
            # Explore dataset structure
            logging.info("Available datasets:")
            for key in f.keys():
                logging.info(f"  - {key}: {f[key].shape}")
            
            # Load sparse matrix components
            if all(key in f.keys() for key in ['row', 'col', 'data', 'shape']):
                from scipy.sparse import coo_matrix, csr_matrix
                
                row = f['row'][:]
                col = f['col'][:]
                data = f['data'][:]
                shape = f['shape'][:]
                
                logging.info(f"Sparse matrix shape: {shape}")
                logging.info(f"Non-zero elements: {len(data)}")
                
                # Create sparse matrix (keep in COO format for memory efficiency)
                sparse_features = coo_matrix((data, (row, col)), shape=shape)
                X_sparse = sparse_features.tocsr()  # Convert to CSR for efficient operations
                
            else:
                raise ValueError("Sparse matrix components not found in HDF5 file")
            
            # Load labels
            if 'mitre_ids' in f.keys():
                y = f['mitre_ids'][:]
                if isinstance(y[0], bytes):
                    y = [label.decode('utf-8') for label in y]
                logging.info(f"Loaded {len(y)} labels")
            else:
                raise ValueError("MITRE IDs not found in HDF5 file")
        
        return X_sparse, np.array(y)
    
    def stratified_train_test_split(self, X, y):
        """Stratified split ensuring all classes are represented in both sets"""
        logging.info("Performing stratified train-test split...")
        
        unique_classes, class_counts = np.unique(y, return_counts=True)
        logging.info(f"Class distribution: {dict(zip(unique_classes, class_counts))}")
        
        # Use stratified shuffle split for proportional representation
        sss = StratifiedShuffleSplit(n_splits=1, test_size=self.test_size, 
                                   random_state=self.random_state)
        
        for train_idx, test_idx in sss.split(X, y):
            X_train, X_test = X[train_idx], X[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]
        
        # Verify all classes are present in both sets
        train_classes = np.unique(y_train)
        test_classes = np.unique(y_test)
        
        logging.info(f"Training set: {X_train.shape[0]} samples, {len(train_classes)} classes")
        logging.info(f"Testing set: {X_test.shape[0]} samples, {len(test_classes)} classes")
        
        if len(train_classes) != len(test_classes):
            logging.warning("Not all classes represented in both training and testing sets")
        
        return X_train, X_test, y_train, y_test
    
    def reduce_dimensionality(self, X_sparse):
        """Reduce dimensionality using sparse-compatible methods"""
        logging.info(f"Reducing dimensionality from {X_sparse.shape[1]} to {self.max_features} features")
        
        # Method 1: TruncatedSVD (PCA for sparse data)
        svd = TruncatedSVD(n_components=min(self.max_features, X_sparse.shape[1]), 
                          random_state=self.random_state)
        X_reduced = svd.fit_transform(X_sparse)
        
        explained_variance = np.sum(svd.explained_variance_ratio_)
        logging.info(f"SVD explained variance: {explained_variance:.4f}")
        
        return X_reduced, svd
    
    def preprocess_data(self, X_sparse, y):
        """Complete preprocessing pipeline"""
        # Encode labels
        y_encoded = self.label_encoder.fit_transform(y)
        logging.info(f"Encoded {len(self.label_encoder.classes_)} classes: {self.label_encoder.classes_}")
        
        # Split data
        X_train, X_test, y_train, y_test = self.stratified_train_test_split(X_sparse, y_encoded)
        
        # Reduce dimensionality
        X_train_reduced, self.dim_reducer = self.reduce_dimensionality(X_train)
        X_test_reduced = self.dim_reducer.transform(X_test)
        
        # Scale features (using with_mean=False for sparse data)
        X_train_scaled = self.scaler.fit_transform(X_train_reduced)
        X_test_scaled = self.scaler.transform(X_test_reduced)
        
        logging.info(f"Final feature dimensions: {X_train_scaled.shape[1]}")
        
        return X_train_scaled, X_test_scaled, y_train, y_test

class ClassificationEvaluator:
    """Comprehensive model evaluation and visualization"""
    
    def __init__(self, label_encoder):
        self.label_encoder = label_encoder
        self.results = {}
        
    def evaluate_model(self, model, X_test, y_test, model_name, training_time):
        """Comprehensive model evaluation"""
        start_time = time.time()
        y_pred = model.predict(X_test)
        prediction_time = time.time() - start_time
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
        recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
        f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
        
        # Store results
        self.results[model_name] = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'training_time': training_time,
            'prediction_time': prediction_time,
            'y_true': y_test,
            'y_pred': y_pred
        }
        
        logging.info(f"{model_name} Evaluation:")
        logging.info(f"  Accuracy: {accuracy:.4f}")
        logging.info(f"  Precision: {precision:.4f}")
        logging.info(f"  Recall: {recall:.4f}")
        logging.info(f"  F1-Score: {f1:.4f}")
        logging.info(f"  Training Time: {training_time:.2f}s")
        logging.info(f"  Prediction Time: {prediction_time:.2f}s")
        
        return self.results[model_name]
    
    def plot_confusion_matrix(self, y_true, y_pred, model_name, class_names):
        """Plot professional confusion matrix"""
        cm = confusion_matrix(y_true, y_pred)
        
        plt.figure(figsize=(12, 10))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=class_names, yticklabels=class_names)
        plt.title(f'Confusion Matrix - {model_name}', fontsize=16, fontweight='bold')
        plt.xlabel('Predicted Label', fontsize=12)
        plt.ylabel('True Label', fontsize=12)
        plt.xticks(rotation=45, ha='right')
        plt.yticks(rotation=0)
        plt.tight_layout()
        plt.savefig(f'confusion_matrix_{model_name.lower().replace(" ", "_")}.pdf', 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_metrics_comparison(self):
        """Plot comparative performance of all models"""
        models = list(self.results.keys())
        metrics = ['accuracy', 'precision', 'recall', 'f1_score']
        
        # Create subplots
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        axes = axes.ravel()
        
        for i, metric in enumerate(metrics):
            values = [self.results[model][metric] for model in models]
            
            bars = axes[i].bar(models, values, color=plt.cm.Set3(np.linspace(0, 1, len(models))))
            axes[i].set_title(f'{metric.title()} Comparison', fontsize=14, fontweight='bold')
            axes[i].set_ylabel(metric.title(), fontsize=12)
            axes[i].set_ylim(0, 1)
            axes[i].tick_params(axis='x', rotation=45)
            
            # Add value labels on bars
            for bar, value in zip(bars, values):
                height = bar.get_height()
                axes[i].text(bar.get_x() + bar.get_width()/2., height,
                           f'{value:.3f}', ha='center', va='bottom', fontweight='bold')
        
        plt.tight_layout()
        plt.savefig('model_performance_comparison.pdf', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_training_metrics(self, history, model_name):
        """Plot training metrics evolution (for models that support it)"""
        if history is None:
            return
            
        plt.figure(figsize=(12, 8))
        
        if 'loss' in history:
            plt.subplot(2, 2, 1)
            plt.plot(history['loss'], label='Training Loss')
            if 'val_loss' in history:
                plt.plot(history['val_loss'], label='Validation Loss')
            plt.title('Loss Evolution')
            plt.legend()
        
        metrics = ['accuracy', 'precision', 'recall', 'f1_score']
        for i, metric in enumerate(metrics, 2):
            if metric in history:
                plt.subplot(2, 2, i)
                plt.plot(history[metric], label=f'Training {metric}')
                if f'val_{metric}' in history:
                    plt.plot(history[f'val_{metric}'], label=f'Validation {metric}')
                plt.title(f'{metric.title()} Evolution')
                plt.legend()
        
        plt.suptitle(f'Training Metrics - {model_name}', fontsize=16, fontweight='bold')
        plt.tight_layout()
        plt.savefig(f'training_metrics_{model_name.lower().replace(" ", "_")}.pdf', 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def generate_summary_report(self):
        """Generate comprehensive summary report"""
        summary_lines = []
        summary_lines.append("CLASSIFICATION RESULTS SUMMARY")
        summary_lines.append("=" * 50)
        summary_lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        summary_lines.append("")
        
        # Individual model results
        for model_name, results in self.results.items():
            summary_lines.append(f"{model_name.upper()}")
            summary_lines.append("-" * 30)
            summary_lines.append(f"Accuracy:    {results['accuracy']:.4f}")
            summary_lines.append(f"Precision:   {results['precision']:.4f}")
            summary_lines.append(f"Recall:      {results['recall']:.4f}")
            summary_lines.append(f"F1-Score:    {results['f1_score']:.4f}")
            summary_lines.append(f"Training:    {results['training_time']:.2f}s")
            summary_lines.append(f"Prediction:  {results['prediction_time']:.2f}s")
            summary_lines.append("")
        
        # Comparative analysis
        summary_lines.append("COMPARATIVE ANALYSIS")
        summary_lines.append("-" * 30)
        
        best_accuracy = max(self.results.values(), key=lambda x: x['accuracy'])
        best_f1 = max(self.results.values(), key=lambda x: x['f1_score'])
        fastest_training = min(self.results.values(), key=lambda x: x['training_time'])
        
        best_accuracy_model = [k for k, v in self.results.items() if v == best_accuracy][0]
        best_f1_model = [k for k, v in self.results.items() if v == best_f1][0]
        fastest_model = [k for k, v in self.results.items() if v == fastest_training][0]
        
        summary_lines.append(f"Best Accuracy: {best_accuracy_model} ({best_accuracy['accuracy']:.4f})")
        summary_lines.append(f"Best F1-Score: {best_f1_model} ({best_f1['f1_score']:.4f})")
        summary_lines.append(f"Fastest Training: {fastest_model} ({fastest_training['training_time']:.2f}s)")
        
        # Write to file
        with open('classification_summary.txt', 'w') as f:
            f.write('\n'.join(summary_lines))
        
        logging.info("Summary report generated: classification_summary.txt")

def main():
    """Main classification pipeline"""
    parser = argparse.ArgumentParser(description='1-gram Malware Classification')
    parser.add_argument('input_file', help='Input HDF5 file (e.g., 1gramdata.h5)')
    parser.add_argument('--max-features', type=int, default=1000,
                       help='Maximum number of features after dimensionality reduction (default: 1000)')
    parser.add_argument('--test-size', type=float, default=0.3,
                       help='Test set size proportion (default: 0.3)')
    
    args = parser.parse_args()
    
    # Setup logging
    log_filename = setup_logging()
    logging.info(f"Starting 1-gram classification pipeline")
    logging.info(f"Input file: {args.input_file}")
    logging.info(f"Max features: {args.max_features}")
    logging.info(f"Test size: {args.test_size}")
    
    try:
        # Initialize processor
        processor = SparseDataProcessor(
            max_features=args.max_features,
            test_size=args.test_size,
            random_state=42
        )
        
        # Load and preprocess data
        X_sparse, y = processor.load_sparse_data(args.input_file)
        X_train, X_test, y_train, y_test = processor.preprocess_data(X_sparse, y)
        
        # Calculate class weights for imbalance handling
        class_weights = compute_class_weight('balanced', classes=np.unique(y_train), y=y_train)
        class_weight_dict = dict(zip(np.unique(y_train), class_weights))
        logging.info("Class weights calculated for imbalance handling")
        
        # Initialize evaluator
        evaluator = ClassificationEvaluator(processor.label_encoder)
        
        # Define classifiers with imbalance handling
        classifiers = {
            'SVM': SVC(
                class_weight='balanced',
                random_state=42,
                probability=False
            ),
            'KNN (k=3)': KNeighborsClassifier(n_neighbors=3),
            'KNN (k=5)': KNeighborsClassifier(n_neighbors=5),
            'Decision Tree': DecisionTreeClassifier(
                class_weight='balanced',
                random_state=42,
                max_depth=10  # Prevent overfitting
            )
        }
        
        # Train and evaluate each classifier
        for name, classifier in classifiers.items():
            logging.info(f"\n{'='*50}")
            logging.info(f"Training {name}")
            logging.info(f"{'='*50}")
            
            start_time = time.time()
            classifier.fit(X_train, y_train)
            training_time = time.time() - start_time
            
            # Evaluate model
            results = evaluator.evaluate_model(classifier, X_test, y_test, name, training_time)
            
            # Plot confusion matrix
            class_names = processor.label_encoder.classes_
            evaluator.plot_confusion_matrix(results['y_true'], results['y_pred'], name, class_names)
            
            # Generate classification report
            report = classification_report(results['y_true'], results['y_pred'], 
                                         target_names=class_names, zero_division=0)
            logging.info(f"\nClassification Report for {name}:\n{report}")
        
        # Generate comparative visualizations and summary
        evaluator.plot_metrics_comparison()
        evaluator.generate_summary_report()
        
        logging.info(f"\n{'='*50}")
        logging.info("CLASSIFICATION PIPELINE COMPLETED SUCCESSFULLY")
        logging.info(f"{'='*50}")
        logging.info(f"Log file: {log_filename}")
        logging.info(f"Summary report: classification_summary.txt")
        logging.info(f"Visualizations saved as PDF files")
        
    except Exception as e:
        logging.error(f"Error in classification pipeline: {e}")
        raise

if __name__ == "__main__":
    main()