import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

# Set style for publication-quality plots
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")

# Data from the provided files
data = {
    'Model': ['Linear SVM', 'KNN (K=3)', 'KNN (K=5)', 'Decision Tree'] * 2,
    'N-Gram': ['2-Gram'] * 4 + ['1-Gram'] * 4,
    'Accuracy': [0.6123, 0.5000, 0.4912, 0.1938, 0.1762, 0.1740, 0.1564, 0.1520],
    'Precision': [0.6198, 0.4943, 0.4769, 0.4022, 0.4016, 0.1423, 0.1377, 0.2366],
    'Recall': [0.6123, 0.5000, 0.4912, 0.1938, 0.1762, 0.1740, 0.1564, 0.1520],
    'F1-Score': [0.6123, 0.4885, 0.4713, 0.2252, 0.1613, 0.1374, 0.1286, 0.1215],
    'Training_Time': [75.90, 0.01, 0.00, 1.07, 0.67, 0.00, 0.00, 1.63],
    'Prediction_Time': [0.00, 0.17, 0.01, 0.00, 0.42, 0.05, 0.03, 0.00]
}

df = pd.DataFrame(data)

# Create subplots
fig, axes = plt.subplots(2, 2, figsize=(15, 12))
fig.suptitle('Comparison of 1-Gram vs 2-Gram Classification Performance Across Machine Learning Models', 
             fontsize=16, fontweight='bold', y=0.98)

# Plot 1: Accuracy Comparison
ax1 = axes[0, 0]
x = np.arange(len(df['Model'].unique()))
width = 0.35

for i, model in enumerate(df['Model'].unique()):
    model_data = df[df['Model'] == model]
    gram1_acc = model_data[model_data['N-Gram'] == '1-Gram']['Accuracy'].values[0]
    gram2_acc = model_data[model_data['N-Gram'] == '2-Gram']['Accuracy'].values[0]
    
    ax1.bar(i - width/2, gram1_acc, width, label='1-Gram' if i == 0 else "", 
            color='lightcoral', alpha=0.8, edgecolor='darkred', linewidth=1)
    ax1.bar(i + width/2, gram2_acc, width, label='2-Gram' if i == 0 else "", 
            color='lightsteelblue', alpha=0.8, edgecolor='darkblue', linewidth=1)

ax1.set_xlabel('Machine Learning Model', fontsize=12, fontweight='bold')
ax1.set_ylabel('Accuracy', fontsize=12, fontweight='bold')
ax1.set_title('A) Accuracy Comparison', fontsize=14, fontweight='bold')
ax1.set_xticks(x)
ax1.set_xticklabels(df['Model'].unique(), rotation=45, ha='right')
ax1.legend()
ax1.grid(True, alpha=0.3)
ax1.set_ylim(0, 0.7)

# Add value labels on bars
for i, model in enumerate(df['Model'].unique()):
    model_data = df[df['Model'] == model]
    gram1_acc = model_data[model_data['N-Gram'] == '1-Gram']['Accuracy'].values[0]
    gram2_acc = model_data[model_data['N-Gram'] == '2-Gram']['Accuracy'].values[0]
    
    ax1.text(i - width/2, gram1_acc + 0.01, f'{gram1_acc:.3f}', 
             ha='center', va='bottom', fontsize=9, fontweight='bold')
    ax1.text(i + width/2, gram2_acc + 0.01, f'{gram2_acc:.3f}', 
             ha='center', va='bottom', fontsize=9, fontweight='bold')

# Plot 2: F1-Score Comparison
ax2 = axes[0, 1]
for i, model in enumerate(df['Model'].unique()):
    model_data = df[df['Model'] == model]
    gram1_f1 = model_data[model_data['N-Gram'] == '1-Gram']['F1-Score'].values[0]
    gram2_f1 = model_data[model_data['N-Gram'] == '2-Gram']['F1-Score'].values[0]
    
    ax2.bar(i - width/2, gram1_f1, width, label='1-Gram' if i == 0 else "", 
            color='lightcoral', alpha=0.8, edgecolor='darkred', linewidth=1)
    ax2.bar(i + width/2, gram2_f1, width, label='2-Gram' if i == 0 else "", 
            color='lightsteelblue', alpha=0.8, edgecolor='darkblue', linewidth=1)

ax2.set_xlabel('Machine Learning Model', fontsize=12, fontweight='bold')
ax2.set_ylabel('F1-Score', fontsize=12, fontweight='bold')
ax2.set_title('B) F1-Score Comparison', fontsize=14, fontweight='bold')
ax2.set_xticks(x)
ax2.set_xticklabels(df['Model'].unique(), rotation=45, ha='right')
ax2.legend()
ax2.grid(True, alpha=0.3)
ax2.set_ylim(0, 0.7)

# Add value labels on bars
for i, model in enumerate(df['Model'].unique()):
    model_data = df[df['Model'] == model]
    gram1_f1 = model_data[model_data['N-Gram'] == '1-Gram']['F1-Score'].values[0]
    gram2_f1 = model_data[model_data['N-Gram'] == '2-Gram']['F1-Score'].values[0]
    
    ax2.text(i - width/2, gram1_f1 + 0.01, f'{gram1_f1:.3f}', 
             ha='center', va='bottom', fontsize=9, fontweight='bold')
    ax2.text(i + width/2, gram2_f1 + 0.01, f'{gram2_f1:.3f}', 
             ha='center', va='bottom', fontsize=9, fontweight='bold')

# Plot 3: Training Time Comparison (log scale)
ax3 = axes[1, 0]
training_times_1gram = []
training_times_2gram = []

for model in df['Model'].unique():
    model_data = df[df['Model'] == model]
    training_times_1gram.append(model_data[model_data['N-Gram'] == '1-Gram']['Training_Time'].values[0])
    training_times_2gram.append(model_data[model_data['N-Gram'] == '2-Gram']['Training_Time'].values[0])

x = np.arange(len(df['Model'].unique()))
ax3.bar(x - width/2, training_times_1gram, width, label='1-Gram', 
        color='lightcoral', alpha=0.8, edgecolor='darkred', linewidth=1)
ax3.bar(x + width/2, training_times_2gram, width, label='2-Gram', 
        color='lightsteelblue', alpha=0.8, edgecolor='darkblue', linewidth=1)

ax3.set_xlabel('Machine Learning Model', fontsize=12, fontweight='bold')
ax3.set_ylabel('Training Time (seconds)', fontsize=12, fontweight='bold')
ax3.set_title('C) Training Time Comparison', fontsize=14, fontweight='bold')
ax3.set_xticks(x)
ax3.set_xticklabels(df['Model'].unique(), rotation=45, ha='right')
ax3.legend()
ax3.grid(True, alpha=0.3)
ax3.set_yscale('log')  # Log scale due to large variation in training times

# Add value labels on bars (for non-zero values)
for i, (t1, t2) in enumerate(zip(training_times_1gram, training_times_2gram)):
    if t1 > 0:
        ax3.text(i - width/2, t1 * 1.1, f'{t1:.2f}s', 
                 ha='center', va='bottom', fontsize=8, fontweight='bold')
    if t2 > 0:
        ax3.text(i + width/2, t2 * 1.1, f'{t2:.2f}s', 
                 ha='center', va='bottom', fontsize=8, fontweight='bold')

# Plot 4: Performance Improvement (2-gram vs 1-gram)
ax4 = axes[1, 1]
improvement_data = []

for model in df['Model'].unique():
    model_data = df[df['Model'] == model]
    gram1_acc = model_data[model_data['N-Gram'] == '1-Gram']['Accuracy'].values[0]
    gram2_acc = model_data[model_data['N-Gram'] == '2-Gram']['Accuracy'].values[0]
    improvement = ((gram2_acc - gram1_acc) / gram1_acc) * 100
    improvement_data.append(improvement)

colors = ['green' if x > 0 else 'red' for x in improvement_data]
bars = ax4.bar(x, improvement_data, color=colors, alpha=0.7, edgecolor='black', linewidth=1)

ax4.set_xlabel('Machine Learning Model', fontsize=12, fontweight='bold')
ax4.set_ylabel('Accuracy Improvement (%)', fontsize=12, fontweight='bold')
ax4.set_title('D) Performance Improvement: 2-Gram vs 1-Gram', fontsize=14, fontweight='bold')
ax4.set_xticks(x)
ax4.set_xticklabels(df['Model'].unique(), rotation=45, ha='right')
ax4.grid(True, alpha=0.3)
ax4.axhline(y=0, color='black', linestyle='-', alpha=0.8)

# Add value labels on bars
for i, bar in enumerate(bars):
    height = bar.get_height()
    va = 'bottom' if height >= 0 else 'top'
    color = 'darkgreen' if height >= 0 else 'darkred'
    ax4.text(bar.get_x() + bar.get_width()/2., height + (5 if height >= 0 else -5), 
             f'{height:.1f}%', ha='center', va=va, fontsize=9, fontweight='bold', color=color)

plt.tight_layout()
plt.subplots_adjust(top=0.94)

# Save the figure
plt.savefig('1_2gram_classification_comparison.png', dpi=300, bbox_inches='tight')
plt.savefig('1_2gram_classification_comparison.pdf', bbox_inches='tight')

plt.show()

# Print summary statistics
print("=" * 70)
print("SUMMARY STATISTICS")
print("=" * 70)
print(f"{'Model':<15} {'1-Gram Accuracy':<15} {'2-Gram Accuracy':<15} {'Improvement':<15}")
print("-" * 70)
for model in df['Model'].unique():
    model_data = df[df['Model'] == model]
    gram1_acc = model_data[model_data['N-Gram'] == '1-Gram']['Accuracy'].values[0]
    gram2_acc = model_data[model_data['N-Gram'] == '2-Gram']['Accuracy'].values[0]
    improvement = ((gram2_acc - gram1_acc) / gram1_acc) * 100
    print(f"{model:<15} {gram1_acc:<15.4f} {gram2_acc:<15.4f} {improvement:<15.1f}%")

print("\nKey Findings:")
print("• 2-gram features consistently outperform 1-gram features across all models")
print("• Linear SVM shows the best overall performance with both 1-gram and 2-gram features")
print("• The improvement is most dramatic for Linear SVM (+247.5% improvement)")
print("• KNN models show moderate improvement with 2-gram features")
print("• Decision Tree shows the smallest relative improvement")