#!/usr/bin/env python3
"""
2-gram Malware Opcode Visualization
Usage: python 2gram_viz.py --input 2gramdata.h5
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import h5py
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import TruncatedSVD  # For sparse matrices
from scipy.sparse import coo_matrix, csr_matrix
from scipy.spatial import ConvexHull
import os
import argparse

def load_2gram_data(h5_file_path):
    """
    Load 2-gram data from HDF5 file while keeping it sparse
    """
    print(f"Loading data from {h5_file_path}...")
    
    with h5py.File(h5_file_path, 'r') as f:
        # Explore available datasets
        print("Available datasets in HDF5 file:")
        for key in f.keys():
            dataset = f[key]
            print(f"  - {key}: {dataset.shape} (dtype: {dataset.dtype})")
        
        # Load sparse matrix components
        if all(key in f.keys() for key in ['row', 'col', 'data', 'shape']):
            print("Detected sparse matrix format (COO)...")
            
            # Load sparse matrix components
            row = f['row'][:]
            col = f['col'][:]
            data = f['data'][:]
            shape = f['shape'][:]
            
            print(f"Sparse matrix shape: {shape}")
            print(f"Non-zero elements: {len(data)}")
            
            # Create sparse matrix and keep it sparse
            sparse_features = coo_matrix((data, (row, col)), shape=shape)
            features_csr = sparse_features.tocsr()  # Keep as CSR for efficient operations
            
            print(f"Keeping features in sparse format: {features_csr.shape}")
        
        else:
            raise ValueError("Could not find sparse matrix data in HDF5 file")
        
        # Load filenames
        if 'filenames' in f.keys():
            filenames = f['filenames'][:]
            # Convert bytes to strings if needed
            if isinstance(filenames[0], bytes):
                filenames = [f.decode('utf-8') for f in filenames]
        else:
            filenames = np.array([f'sample_{i}' for i in range(features_csr.shape[0])])
        
        # Load labels
        if 'mitre_ids' in f.keys():
            labels = f['mitre_ids'][:]
            # Convert bytes to strings if needed
            if isinstance(labels[0], bytes):
                labels = [label.decode('utf-8') for label in labels]
            print(f"Using MITRE IDs as labels")
        else:
            # Create labels from filenames
            labels = []
            for filename in filenames:
                filename_lower = filename.lower()
                if 'trojan' in filename_lower:
                    labels.append('Trojan')
                elif 'ransom' in filename_lower:
                    labels.append('Ransomware')
                elif 'virus' in filename_lower:
                    labels.append('Virus')
                elif 'worm' in filename_lower:
                    labels.append('Worm')
                elif 'backdoor' in filename_lower:
                    labels.append('Backdoor')
                elif 'spyware' in filename_lower:
                    labels.append('Spyware')
                elif 'adware' in filename_lower:
                    labels.append('Adware')
                else:
                    labels.append('Unknown')
            labels = np.array(labels)
            print("Created labels from filenames")
        
        # Load feature names
        if 'two_gram_vocabulary' in f.keys():
            feature_names = f['two_gram_vocabulary'][:]
            # Convert bytes to strings if needed
            if isinstance(feature_names[0], bytes):
                feature_names = [name.decode('utf-8') for name in feature_names]
            print(f"Loaded {len(feature_names)} 2-gram features")
        else:
            feature_names = np.array([f'2gram_{i}' for i in range(features_csr.shape[1])])
    
    print(f"Final dataset: {features_csr.shape[0]} samples, {features_csr.shape[1]} features")
    print(f"Label distribution:")
    unique_labels, counts = np.unique(labels, return_counts=True)
    for label, count in zip(unique_labels, counts):
        print(f"  - {label}: {count} samples")
    
    return features_csr, labels, filenames, feature_names

def reduce_dimensionality_sparse(features_csr, n_components=100):
    """
    Reduce dimensionality of sparse matrix using TruncatedSVD
    """
    print(f"Reducing dimensionality from {features_csr.shape[1]} to {n_components} features using TruncatedSVD...")
    
    # Use TruncatedSVD for sparse matrices (equivalent to PCA)
    svd = TruncatedSVD(n_components=n_components, random_state=42, algorithm='arpack')
    features_reduced = svd.fit_transform(features_csr)
    
    explained_variance = np.sum(svd.explained_variance_ratio_)
    print(f"TruncatedSVD explained variance: {explained_variance:.4f} ({explained_variance*100:.2f}%)")
    
    return features_reduced, svd

def create_publication_visualization(features_csr, labels, output_file="2gram_tsne_visualization.pdf"):
    """
    Create publication-quality t-SNE visualization for 2-gram features
    """
    
    # Set professional style
    plt.style.use('default')
    sns.set_palette("tab20")
    plt.rcParams['font.family'] = 'DejaVu Sans'
    plt.rcParams['font.size'] = 10
    plt.rcParams['axes.linewidth'] = 1.2
    
    # Create figure with subplots
    fig = plt.figure(figsize=(24, 10))
    gs = fig.add_gridspec(2, 4, height_ratios=[3, 1])
    
    # Main visualization subplots
    ax1 = fig.add_subplot(gs[0, :2])  # t-SNE plot with convex hulls
    ax2 = fig.add_subplot(gs[0, 2])   # SVD variance
    ax3 = fig.add_subplot(gs[0, 3])   # Cluster quality
    ax4 = fig.add_subplot(gs[1, :])   # Statistics
    
    fig.suptitle('Comprehensive 2-gram Opcode Analysis using t-SNE', 
                 fontsize=18, fontweight='bold', y=0.98)
    
    # Preprocessing and dimensionality reduction
    print("Preprocessing data...")
    
    # Reduce dimensionality with TruncatedSVD first (essential for high-dimensional 2-grams)
    features_reduced, svd = reduce_dimensionality_sparse(features_csr, n_components=100)
    
    # Standardize the reduced features
    scaler = StandardScaler()
    features_standardized = scaler.fit_transform(features_reduced)
    
    # Perform t-SNE
    print("Running t-SNE on reduced features...")
    tsne = TSNE(n_components=2, 
                random_state=42, 
                perplexity=min(40, len(features_standardized) - 1),
                max_iter=1500,
                init='pca',
                learning_rate='auto',
                metric='cosine',
                verbose=1)
    
    tsne_results = tsne.fit_transform(features_standardized)
    
    # Create DataFrame for plotting
    tsne_df = pd.DataFrame({
        'TSNE1': tsne_results[:, 0],
        'TSNE2': tsne_results[:, 1],
        'Label': labels
    })
    
    # Define colors for consistent family representation
    unique_labels = np.unique(labels)
    colors = plt.cm.tab20(np.linspace(0, 1, len(unique_labels)))
    family_colors = {label: colors[i] for i, label in enumerate(unique_labels)}
    
    # Plot 1: Main t-SNE visualization with convex hulls
    texts = []
    for i, label in enumerate(unique_labels):
        mask = tsne_df['Label'] == label
        subset = tsne_df[mask]
        
        if len(subset) > 0:
            # Plot points
            ax1.scatter(subset['TSNE1'], subset['TSNE2'],
                       c=[family_colors[label]],
                       label=f'{label} ({len(subset)})',
                       alpha=0.8,
                       s=60,
                       edgecolors='white',
                       linewidth=0.8,
                       zorder=3)
            
            # Add convex hull for cluster visualization (only for larger groups)
            if len(subset) >= 5:  # Require more points for meaningful hulls
                try:
                    points = subset[['TSNE1', 'TSNE2']].values
                    hull = ConvexHull(points)
                    
                    # Plot convex hull
                    for simplex in hull.simplices:
                        ax1.plot(points[simplex, 0], points[simplex, 1],
                                color=family_colors[label], alpha=0.3, 
                                linewidth=2, zorder=2)
                except:
                    pass  # Skip if convex hull fails
            
            # Add family label at centroid for larger groups
            if len(subset) >= 10:
                centroid_x = subset['TSNE1'].mean()
                centroid_y = subset['TSNE2'].mean()
                text = ax1.text(centroid_x, centroid_y, label, 
                               fontsize=8, fontweight='bold', ha='center',
                               bbox=dict(boxstyle="round,pad=0.2", 
                                        facecolor=family_colors[label], 
                                        alpha=0.7))
                texts.append(text)
    
    ax1.set_xlabel('t-SNE Component 1', fontsize=12, fontweight='bold')
    ax1.set_ylabel('t-SNE Component 2', fontsize=12, fontweight='bold')
    ax1.set_title('2-gram Opcode Clustering with Convex Hulls', 
                  fontsize=14, fontweight='bold')
    ax1.grid(True, alpha=0.3, linestyle='--')
    ax1.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
    
    # Plot 2: SVD explained variance
    explained_variance = svd.explained_variance_ratio_
    cumulative_variance = np.cumsum(explained_variance)
    
    ax2.bar(range(1, len(explained_variance) + 1), explained_variance, 
           alpha=0.7, color='skyblue', label='Individual')
    ax2.plot(range(1, len(cumulative_variance) + 1), cumulative_variance,
            color='red', marker='o', linewidth=2, label='Cumulative')
    
    ax2.set_xlabel('SVD Component', fontsize=10, fontweight='bold')
    ax2.set_ylabel('Explained Variance Ratio', fontsize=10, fontweight='bold')
    ax2.set_title('SVD Variance Explanation\n(Pre-t-SNE)', 
                 fontsize=12, fontweight='bold')
    ax2.legend(fontsize=8)
    ax2.grid(True, alpha=0.3)
    
    # Plot 3: Cluster separation metrics
    cluster_stats = []
    for label in unique_labels:
        mask = tsne_df['Label'] == label
        subset = tsne_df[mask]
        if len(subset) > 1:
            cluster_stats.append({
                'Family': label,
                'Count': len(subset),
                'TSNE1_std': subset['TSNE1'].std(),
                'TSNE2_std': subset['TSNE2'].std(),
                'Cluster_Compactness': len(subset) / (subset['TSNE1'].std() * subset['TSNE2'].std() + 1e-8)
            })
    
    if cluster_stats:
        stats_df = pd.DataFrame(cluster_stats)
        
        # Plot cluster compactness for groups with sufficient samples
        large_groups = stats_df[stats_df['Count'] >= 5]
        if len(large_groups) > 0:
            families = large_groups['Family']
            compactness = large_groups['Cluster_Compactness']
            
            bars = ax3.bar(range(len(families)), compactness,
                          color=[family_colors[fam] for fam in families],
                          alpha=0.7)
            
            ax3.set_xlabel('Malware Family', fontsize=10, fontweight='bold')
            ax3.set_ylabel('Cluster Compactness', fontsize=10, fontweight='bold')
            ax3.set_title('Cluster Quality Metrics\n(Groups with ≥5 samples)', 
                         fontsize=12, fontweight='bold')
            ax3.set_xticks(range(len(families)))
            ax3.set_xticklabels(families, rotation=45, ha='right', fontsize=7)
            
            # Add value labels on bars
            for bar, value in zip(bars, compactness):
                height = bar.get_height()
                ax3.text(bar.get_x() + bar.get_width()/2., height,
                        f'{value:.1f}', ha='center', va='bottom', fontsize=6, fontweight='bold')
    
    # Plot 4: Family distribution statistics
    family_counts = pd.Series(labels).value_counts()
    family_colors_plot = [family_colors[fam] for fam in family_counts.index]
    
    bars = ax4.bar(range(len(family_counts)), family_counts.values, 
                  color=family_colors_plot, alpha=0.7)
    ax4.set_xlabel('MITRE ATT&CK Group', fontsize=10, fontweight='bold')
    ax4.set_ylabel('Sample Count', fontsize=10, fontweight='bold')
    ax4.set_title('Dataset Distribution by Group', fontsize=12, fontweight='bold')
    ax4.set_xticks(range(len(family_counts)))
    ax4.set_xticklabels(family_counts.index, rotation=45, ha='right', fontsize=8)
    
    # Add value labels on bars
    for bar, count in zip(bars, family_counts.values):
        height = bar.get_height()
        ax4.text(bar.get_x() + bar.get_width()/2., height,
                f'{count}', ha='center', va='bottom', fontsize=8, fontweight='bold')
    
    # Add comprehensive annotations
    annotation_text = f"""
2-gram Analysis Summary:
• Total Samples: {features_csr.shape[0]:,}
• Original 2-gram Features: {features_csr.shape[1]:,}
• Reduced Features (SVD): {features_reduced.shape[1]:,}
• MITRE Groups: {len(unique_labels)}
• SVD Variance Explained: {np.sum(svd.explained_variance_ratio_):.3f}
• t-SNE KL Divergence: {tsne.kl_divergence_:.4f}
    """
    
    fig.text(0.02, 0.02, annotation_text, fontsize=9,
            bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgray", alpha=0.8),
            verticalalignment='bottom')
    
    # Adjust layout and save
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight', 
                facecolor='white', edgecolor='none')
    
    print(f"Main visualization saved as: {output_file}")
    
    return tsne_results, family_colors

def create_additional_visualizations(labels, tsne_results, family_colors):
    """
    Create additional visualizations without requiring full feature matrix
    """
    
    # Visualization 2: Enhanced cluster plot
    plt.figure(figsize=(16, 10))
    
    tsne_df = pd.DataFrame({
        'TSNE1': tsne_results[:, 0],
        'TSNE2': tsne_results[:, 1],
        'Label': labels
    })
    
    unique_labels = np.unique(labels)
    
    # Create enhanced scatter plot
    for label in unique_labels:
        mask = tsne_df['Label'] == label
        if mask.sum() > 0:
            plt.scatter(tsne_df.loc[mask, 'TSNE1'], tsne_df.loc[mask, 'TSNE2'],
                       c=[family_colors[label]],
                       label=f'{label} ({mask.sum()})',
                       alpha=0.7, s=60, edgecolors='black', linewidth=0.5)
    
    plt.xlabel('t-SNE Component 1', fontsize=14, fontweight='bold')
    plt.ylabel('t-SNE Component 2', fontsize=14, fontweight='bold')
    plt.title('2-gram Opcode Pattern Clustering\n(MITRE ATT&CK Group Separation)', 
              fontsize=16, fontweight='bold')
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=9)
    plt.grid(True, alpha=0.3)
    
    plt.savefig('2gram_enhanced_clusters.pdf', dpi=300, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    
    print("Additional visualizations created successfully")

def main():
    """Main function to run the 2-gram visualization"""
    
    # Set up argument parser
    parser = argparse.ArgumentParser(description='Visualize 2-gram malware opcode data')
    parser.add_argument('--input', default='2gramdata.h5', 
                       help='Input HDF5 file (default: 2gramdata.h5)')
    parser.add_argument('--output', default='2gram_tsne_visualization.pdf',
                       help='Output PDF file (default: 2gram_tsne_visualization.pdf)')
    
    args = parser.parse_args()
    
    # Check if input file exists
    if not os.path.exists(args.input):
        print(f"Error: Input file '{args.input}' not found!")
        print("Please ensure the HDF5 file is in the current directory")
        print("Current directory contents:")
        for file in os.listdir('.'):
            if file.endswith('.h5') or file.endswith('.hdf5'):
                print(f"  - {file}")
        return
    
    try:
        # Load data - keeping it sparse to save memory
        print("Loading 2-gram data with sparse matrix optimization...")
        features_csr, labels, filenames, feature_names = load_2gram_data(args.input)
        
        # Create main visualization
        print("Creating comprehensive 2-gram visualization...")
        tsne_results, family_colors = create_publication_visualization(features_csr, labels, args.output)
        
        # Create additional visualizations
        print("Creating additional visualizations...")
        create_additional_visualizations(labels, tsne_results, family_colors)
        
        # Print comprehensive summary
        print("\n" + "="*60)
        print("2-GRAM VISUALIZATION COMPLETE")
        print("="*60)
        print(f"Generated files:")
        print(f"  - {args.output} (main comprehensive visualization)")
        print(f"  - 2gram_enhanced_clusters.pdf")
        print(f"\nDataset statistics:")
        print(f"  - Samples: {features_csr.shape[0]:,}")
        print(f"  - 2-gram Features: {features_csr.shape[1]:,}")
        print(f"  - MITRE ATT&CK Groups: {len(np.unique(labels))}")
        print(f"  - Memory efficient: Used sparse matrix operations")
        
        print(f"\nKey Insights:")
        print("• 2-grams capture sequential opcode execution patterns")
        print("• Sparse matrix operations prevent memory overflow")
        print("• MITRE groups show distinct behavioral patterns")
        print("• Convex hulls reveal group clustering tendencies")
        
    except Exception as e:
        print(f"Error during 2-gram visualization: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()